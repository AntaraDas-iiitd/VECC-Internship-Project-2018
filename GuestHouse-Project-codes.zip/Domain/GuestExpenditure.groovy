package in.gov.vecc.veda

class GuestExpenditure {
	
	
	Integer GGE_GID
	Date GGE_DATE
	String GGE_DESCRIPTION
	Integer GGE_AMOUNT

	
	
	
	static mapping = {
		table 'vecusr.GH_GUEST_EXPENDITURE'
		version false
		id generator:"assigned",column: 'GGE_ID'
		}
	 
    static constraints = {
		
		
		GGE_GID(nullable:true)
		GGE_DATE (nullable:true)
		GGE_DESCRIPTION (nullable:true)
		GGE_AMOUNT (nullable:true)
    }
}
