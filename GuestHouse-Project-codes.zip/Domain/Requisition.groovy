package in.gov.vecc.veda

class Requisition {
    
	Integer GR_PERID
	String GR_NAME
	Integer GR_EXTN_NO
	Integer GR_TEL_NO
	Long GR_MOB_NO
	String GR_DESGN
	String GR_DIV
	Integer GR_FAX_NO
	String GR_EMAIL_ID
	Integer GR_SRC_PERID
	Integer GR_DEST_PERID
	Integer GR_APVR_PERID
	String GR_APVR_CMT
	String GR_ICARD_NO
	
	String GR_ADDRESS
	static hasmany= [guests:Guest,families:Family,guestArchives:GuestArchive,comments:Comment]
	
	static mapping = {
		table 'vecusr.GH_Requisition'
		version false
		id generator:"assigned",column: 'GR_ID'
		 }

    static constraints = {
		GR_PERID (nullable:true)
		GR_NAME (nullable:true)
		GR_EXTN_NO (nullable:true)
		GR_TEL_NO (nullable:true)
		GR_MOB_NO (nullable:true)
		GR_DESGN (nullable:true)
		GR_DIV (nullable:true)
		GR_FAX_NO (nullable:true)
		GR_EMAIL_ID (nullable:true)
		GR_SRC_PERID (nullable:true)
		GR_DEST_PERID (nullable:true)
		GR_APVR_PERID (nullable:true)
		GR_APVR_CMT (nullable:true)
		
		GR_ICARD_NO (nullable:true)
		GR_ADDRESS(nullable:true)
    }
}
