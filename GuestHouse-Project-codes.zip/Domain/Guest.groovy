package in.gov.vecc.veda

import java.util.Date;

class Guest {
	
	Integer GG_REQ_ID
	String GG_NAME
	String GG_GENDER
	String GG_EMAIL
	Long GG_PHONE
	String GG_DESGN
	String GG_DIV
	String GG_UNIT
	String GG_ADDRESS
	String GG_STATUS
	Date GG_FROM_DT
	Date GG_TO_DT
	Integer GG_NO_OF_DAYS
	String GG_BED_OR_ROOM
	Integer GG_NO_OF_BED_OR_ROOM
	String GG_CATEGORY
	String GG_PURPOSE
	String GG_PURPOSE_DESC
	String GG_ID_CARD_NO
	String GG_ID_CARD_TYPE
	Integer GG_NO_OF_MEM
	String GG_ROOM_FACILITY
	String GG_GH_TYPE
	String GG_GUEST_PAY_FOR
	String GG_GOV_PAY_FOR
	Byte[] GG_DOC 
	Date GG_REQ_DT
	String GG_PAY_METHOD
	String GG_PAYED_BY
	Integer GG_TID
	
	//static belongsTo= [requisitions:Requisition]
	
	static hasmany=[bills:Bill,guestArchives:GuestArchive,family:Family,guestExpenditures:GuestExpenditure]
	
	static mapping = {
		table 'vecusr.GH_GUEST'
		version false
		id generator:"assigned",column: 'GG_ID'
		}
	
    static constraints = {
	
		GG_REQ_ID (nullable:true)
		GG_NAME (nullable:true)
		GG_GENDER (nullable:true)
		GG_EMAIL (nullable:true)
		GG_PHONE (nullable:true)
		GG_DESGN (nullable:true)
		GG_DIV (nullable:true)
		GG_UNIT (nullable:true)
		GG_ADDRESS (nullable:true)
		GG_STATUS (nullable:true)
		GG_FROM_DT (nullable:true)
		GG_TO_DT (nullable:true)
		GG_NO_OF_DAYS (nullable:true)
		GG_BED_OR_ROOM (nullable:true)
		GG_NO_OF_BED_OR_ROOM (nullable:true)
		GG_CATEGORY (nullable:true)
		GG_PURPOSE_DESC (nullable:true)
		GG_ID_CARD_NO (nullable:true)
		GG_DOC (nullable:true)
		GG_PURPOSE(nullable:true)
		GG_GUEST_PAY_FOR(nullable:true)
		GG_GOV_PAY_FOR(nullable:true)
		GG_ROOM_FACILITY(nullable:true)
		GG_GH_TYPE(nullable:true)
		GG_NO_OF_MEM(nullable:true)
		GG_ID_CARD_TYPE(nullable:true)
		GG_REQ_DT(nullable:true)
		GG_PAY_METHOD(nullable:true)
		GG_PAYED_BY(nullable:true)
		GG_TID(nullable:true)
    }
}
