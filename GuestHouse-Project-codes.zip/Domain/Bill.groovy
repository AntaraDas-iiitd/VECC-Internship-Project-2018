package in.gov.vecc.veda

class Bill {
	
	Integer GB_GID
	Date GB_DATE
	Integer GB_AMOUNT
	String GB_DESC
	String GB_BILL_STATUS
	
	static hasmany=[guestArchives:GuestArchive]
	
	//static belongsTo=[guests:Guest]
	
	static mapping = {
		table 'vecusr.GH_Bill'
		version false
		id generator:"assigned",column: 'GB_ID'
		}
	 
	
    static constraints = {
		
		GB_GID (nullable :true)
		
		GB_DATE (nullable :true)
		GB_AMOUNT (nullable :true)
		GB_DESC (nullable :true)
		GB_BILL_STATUS (nullable :true)
    } 
}
