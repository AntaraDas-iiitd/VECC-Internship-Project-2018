package in.gov.vecc.veda

class Comment {
	
		
		Integer GC_REQ_ID
		Integer GC_SRC_PERID
		Integer GC_DEST_PERID
		String GC_CMT
		String 	GC_STATUS 
	
		static belongsTo=[requisitions:Requisition]
		
		static mapping = {
			table 'vecusr.GH_Comment'
			version false
			id generator:"assigned",column: 'GC_ID'
			}
		
		static constraints = {
		GC_REQ_ID (nullable:true)
		GC_SRC_PERID (nullable:true)
		GC_DEST_PERID (nullable:true)
		GC_CMT (nullable:true)
		GC_STATUS (nullable:true)
    }
}
