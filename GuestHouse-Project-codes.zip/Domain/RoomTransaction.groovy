package in.gov.vecc.veda

class RoomTransaction {

	
	
	Integer GRT_GID
	Integer GRT_GR_ID
	Integer GRT_ROOM_NO
	String GRT_BED_NO
	String GRT_STATUS
	Date GRT_FROM_DT
	Date GRT_TO_DT
	
	String GRT_GH_TYPE
	
	static mapping = {
		table 'VECUSR.GH_Room_Transaction'
		version false
		id generator:"assigned",column:"GRT_ID" } 
	
	
    static constraints = {
		
	
		GRT_GID (nullable : true)
		GRT_GR_ID (nullable : true)
		GRT_ROOM_NO (nullable : true)
		GRT_STATUS(nullable : true)
		GRT_FROM_DT (nullable : true)
		GRT_TO_DT (nullable : true)
		GRT_BED_NO (nullable : true)
		GRT_GH_TYPE (nullable : true)
    }
	
	
	
	
}
