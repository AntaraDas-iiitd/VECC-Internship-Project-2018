package in.gov.vecc.veda

class Tariff {
	
	String GT_CATEGORY
	Integer GT_AC_CHARGE
	Integer GT_NAC_CHARGE 
	
	//static belongsTo=[rooms:Room]
	
	static hasmany=[bills:Bill]
	
	static mapping = {
		table 'VECUSR.GH_Tariff'
		version false
		id generator:"assigned",column:"GT_ID"}
		
	 
    static constraints = { 
		GT_CATEGORY (nullable:true)
		GT_AC_CHARGE (nullable:true)
		GT_NAC_CHARGE (nullable:true)
		} 
}
