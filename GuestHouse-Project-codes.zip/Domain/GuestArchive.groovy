package in.gov.vecc.veda

class GuestArchive {
	
	Integer GGA_GID
	Integer GGA_REQ_ID
	Integer GGA_ROOM_ID
	Integer GGA_BILL_ID
	Date GGA_CHECK_IN_TIME
	Date GGA_CHECK_OUT_TIME
	
	String GGA_REQUISITION_NAME
	String GGA_GUEST_NAME
	Integer GGA_ROOM_NO
	String GGA_BED_NO
	Integer GGA_TOTAL_BILL
	String GGA_FEEDBACK
	String GGA_STATUS
	
	//static belongsTo=[guests:Guest,requisitions:Requisition,rooms:Room,bills:Bill]
	
	static mapping = {
		table 'vecusr.GH_Guest_Archive'
		version false
		
		id generator:"assigned",column: 'GGA_ID'}
	 
    static constraints = {
		
		GGA_GID (nullable : true )	
		GGA_REQ_ID (nullable : true )	
		GGA_ROOM_ID (nullable : true )	
		GGA_BILL_ID (nullable : true )	
		GGA_CHECK_IN_TIME (nullable : true )	
		GGA_CHECK_OUT_TIME (nullable : true )	
		
		GGA_REQUISITION_NAME(nullable : true )	
		GGA_GUEST_NAME(nullable : true )	
		GGA_ROOM_NO(nullable : true )	
		GGA_BED_NO(nullable : true )	
		GGA_TOTAL_BILL(nullable : true )	
		GGA_FEEDBACK(nullable : true )	
		GGA_STATUS(nullable : true )
    }
}
