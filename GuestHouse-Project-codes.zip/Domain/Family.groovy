package in.gov.vecc.veda

class Family {
	
	Integer GF_GID
	
	String GF_NAME
	String GF_GENDER
	String GF_REL_WITH_EMP
	String GF_ID_TYPE
	String GF_ID_NO
	 
	//static belongsTo= [requisitions:Requisition,guests:Guest]
	
	static mapping = {
		table 'vecusr.GH_Family'
		version false
		id generator:"assigned",column: 'GF_ID'
		 }
	
    static constraints = {
		
	
		GF_GID (nullable:true)
		
		GF_NAME (nullable:true)
		GF_GENDER (nullable:true)
		GF_REL_WITH_EMP (nullable:true)
		GF_ID_TYPE (nullable:true)
		GF_ID_NO (nullable:true)
		 
    }
}
