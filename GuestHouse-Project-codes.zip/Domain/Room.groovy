package in.gov.vecc.veda

class Room {
	
	Integer GR_ROOM_NO
	String GR_BED_NO
	String GR_TYPE
	String GR_FACILITY
	Date GR_RESR_FROM
	Date GR_RESR_TO
	String GR_STATUS
	
	//static hasmany=[tariffs:Tariff]
	static mapping = {
		table 'VECUSR.GH_Room'
		version false
		id generator:"assigned",column:"GR_ID" }
	 
    static constraints = {
		
		
		GR_ROOM_NO (nullable : true)
		GR_BED_NO (nullable : true)
		GR_TYPE (nullable : true)
		GR_FACILITY(nullable : true)
		GR_RESR_FROM (nullable : true)
		GR_RESR_TO (nullable : true)
		GR_STATUS(nullable : true)
		
    }
}