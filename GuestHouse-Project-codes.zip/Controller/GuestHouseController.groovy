package in.gov.vecc.veda

import java.util.Date

import groovy.sql.Sql

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.time.*
import java.time.format.DateTimeFormatter

//import java.text.SimpleDateFormat

import com.itextpdf.text.Document
import com.itextpdf.text.Font
import com.itextpdf.text.Paragraph
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfContentByte
import com.itextpdf.text.pdf.GrayColor
import com.itextpdf.text.pdf.PdfGState
import com.itextpdf.text.pdf.PdfWriter
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfPCell
import com.itextpdf.text.pdf.draw.LineSeparator
import com.itextpdf.text.pdf.draw.VerticalPositionMark
import com.itextpdf.text.BaseColor
import com.itextpdf.text.Chunk
import com.itextpdf.text.Phrase
import com.itextpdf.text.Rectangle
import com.itextpdf.text.PageSize
import com.itextpdf.text.Font
import com.itextpdf.text.FontFactory
import com.itextpdf.text.Element
import com.itextpdf.text.TabSettings
import com.itextpdf.text.pdf.PdfStamper
import com.itextpdf.text.pdf.ColumnText
import com.itextpdf.text.pdf.PdfContentByte
import com.itextpdf.text.Image
import com.itextpdf.text.pdf.PdfReader


import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily

class GuestHouseController {
	def dataSource
	
	def printbill()	{
		//println "params.appId"+params.appId
		//def appId =  (new String ((params.appId).decodeBase64())) as long
		
		//def PERID =  (new String ((params.PERID).decodeBase64())) as int
		//println "appId"+appId
		
		def sql = new Sql(dataSource)
	
		
		def emp = EmpDetail.createCriteria()
		def empList = emp.list {
			
		}
		
		
		def ex = GuestExpenditure.createCriteria()
		def expList=ex.list{
			
				eq("GGE_GID",params.gid as int)
			   		
		}
		
	
		
		def bil=Bill.createCriteria()
		def bilList=bil.list{
				eq("GB_GID",params.gid as int)	
		}

		def gue=Guest.createCriteria()
		def guestL=gue.list{
				eq("id",params.gid as long)	
		}
		
	
		
		
			// step 1
		float left = 30;
		float right = 30;
		float top = 60;
		float bottom = 0;
			def document = new Document(PageSize.A4, left, right, top, bottom)
			//println("Document Created")
			
			// step 2
			//PdfWriter.getInstance(document, new FileOutputStream("TaCash111.pdf"))
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PdfWriter.getInstance(document, baos);
			//println("PdfWriter Created")
			

			
			
			// step 3
			document.open()		
			BaseFont ihnd = BaseFont.createFont("web-app/fonts/DVBIYG3NT.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font ifont=new Font(ihnd,14,Font.NORMAL,new BaseColor(0,0,0));
				Font ifontb=new Font(ihnd,14,Font.BOLD,new BaseColor(0,0,0));
				
			BaseFont uhnd = BaseFont.createFont("web-app/fonts/ARIALUNI.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				// for green Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(50,205,50));
				Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(0,0,0));
			BaseFont tnr = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font tnrf=new Font(tnr,12,Font.NORMAL,new BaseColor(50,0,50));
				
				BaseFont tnrb = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font tnrfb=new Font(tnrb,12,Font.BOLD,new BaseColor(50,0,50));
				
			BaseFont fs = BaseFont.createFont("web-app/fonts/FreeSans.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font fsf=new Font(fs,12,Font.NORMAL,new BaseColor(50,205,50));
		
				
				
		
		/*Paragraph p2 = new Paragraph("Ëî÷Ñî Òîú»îÆî/OFG. PAY	¤ï»îïÏ©»î Òîú»îÆîÒîùïÁ/ADL.INC	ËîÙë¬îî¥ì Êî¼îî/D. A. ÇîïÏÒîÙÆî ËîÙë¬îî¥ì Êî¼îî/TRAN DA",ifont)
		document.add(p2);*/
		
			Paragraph p1 =new Paragraph("ÊîîÏ»î ÖîÏ´øîÏ\n GOVERNMENT OF INDIA \n", ifontb)
			p1.setAlignment(Element.ALIGN_CENTER);
			document.add(p1);
			
			Paragraph p2 =new Paragraph("", ufont)
			p2.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk2 = new Chunk("ÇîÏËîîÆîõ ¦²îîì ïÒîÊîî¬î \n Department of Atomic Energy ", ifontb);
			p2.add(chunk2)
			document.add(p2);
			
			Paragraph p3 =new Paragraph("", ufont)
			p3.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk15 = new Chunk("ÇîïÏÒî»îóì ¦²îîì Öîî¥©Ñîîú¶þîýÆî ´úøÆ¿èþ \n Variable Energy Cyclotron Centre", ifontb);
			p3.add(chunk15)
			document.add(p3);
			
			
			/*PdfPTable table4 = new PdfPTable(5.0f,5.0f);
			table4.setWidthPercentage(100);
			
			
			
			table4.addCell("öûø©Öî /FAX: 913323346871")
			table4.addCell("1/§.§öø. ïÒîÅîîÆî Æî¬îÏ/1/A.F Bidhan Nagar")
			
			document.add(table3);
			
			// step 5
			*/
			
			Paragraph p20 =new Paragraph("", ufont);
			p20.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk20 = new Chunk("öûø©Öî/FAX:91332334687                                                        1/§.§öø. ïÒîÅîîÆî Æî¬îÏ/1.A.F Bidhan Nagar\n", ifontb);
			p20.add(chunk20)
			document.add(p20);
			
			
			Paragraph p21 =new Paragraph("", ufont);
			p21.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk21 = new Chunk("öøîúÆî/Phone: ${guestL.GG_PHONE.pop()}   Extn 4408/4409                                        ´øîúÑî´øî»îî-700064/Kolkata-700064\n",ifontb);
			p21.add(chunk21)
			document.add(p21);
			
			Paragraph p22 =new Paragraph("", ufont);
			p22.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk22 = new Chunk("ïÉîÑî Öîë./Bill No. VECC/: ${bilList.id.pop()}",ifontb);
			p22.add(chunk22)
			document.add(p22);
			
			Paragraph p23 =new Paragraph("", ufont);
			p23.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk23 = new Chunk("»îîÏó´ø/ Date : ${bilList.GB_DATE.pop().clearTime()}",ifontb);
			p23.add(chunk23)
			document.add(p23);
		
			Paragraph p4 =new Paragraph("", ufont)
			p4.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk3 = new Chunk("¬îúÖ¶þ Ùî¦Öî ¤îÒîîÖî ÓîõÑ´ø \n  Guest House Accomodation Charges",ifontb);
			chunk3.setUnderline(1.5f, -5.0f);
			p4.add(chunk3)
			document.add(p4);
			Paragraph p =new Paragraph("\n\n", ufont);
			document.add(p);
			
			
			
			def gid=params.gid
			def gname=params.gname
			def gadd=params.gadd
			def gcat=params.gcat
			def fromdt=params.fromdt
			def todt=params.todt
			def pmade=params.pmade
			def pmode=params.pmode
			def nod=params.nod as int
			def lpd=params.lpd as int
			def rcharge=params.rcharge as int
			def fcost=params.fcost as int
			
			
			Paragraph p6 =new Paragraph("", ufont)
			p6.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk4 = new Chunk("ÆîîËî/Name :  ${gname}",ifontb);
			p6.add(chunk4)
			document.add(p6);
			
			Paragraph p7 =new Paragraph("", ufont)
			p7.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk5 = new Chunk("Çî»îî/Address :  ${gadd}",ifontb);
			p6.add(chunk5)
			document.add(p7);
			
			Paragraph p8 =new Paragraph("", ufont)
			p8.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk6 = new Chunk("Çî¦âïÒî ´øîÌîîìÑîÌîóÆî/Category :  ${gcat}",ifontb);
			p8.add(chunk6)
			document.add(p8);
			
			Paragraph p9 =new Paragraph("", ufont)
			p9.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk7 = new Chunk("•þÙÏÆîú ´øó ¤ÒîïÅî/Period of stay :  ${fromdt}  to  ${todt}",ifontb);
			p9.add(chunk7)
			document.add(p9);
			
			Paragraph p10 =new Paragraph("", ufont)
			p10.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk8 = new Chunk("Êîõ¬î»îîÆî ´øîûÆî ´øÏú¬îî/Payment made by :  ${pmade}\n",ifontb);
			p10.add(chunk8)
			document.add(p10);
			
			Paragraph p11 =new Paragraph("", ufont)
			p11.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk9 = new Chunk("Êîõ¬î»îîÆî ´úø Çîè´øîÏ/Payment method :  ${pmode}\n",ifontb);
			p11.add(chunk9)
			document.add(p11);
			
			
			
			Paragraph p12 =new Paragraph("", ufont)
			p12.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk10 = new Chunk("ï¿Æîîú ´øó ÖîëªÌîî/No. of days :  ${nod}\n",ifontb);
			p12.add(chunk10)
			document.add(p12);
			
			Paragraph p13 =new Paragraph("", ufont)
			p13.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk11 = new Chunk("´øËîÏî ÇîèÊîîÏ Çîèï»îï¿Æî / Room charges per day = ${lpd}\n",ifontb);
			p13.add(chunk11)
			document.add(p13);
			
			Paragraph p14 =new Paragraph("", ufont)
			p14.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk12 = new Chunk("´õøÑî ´øËîÏî ÇîèÊîîÏ / Total room Charges = ${rcharge}\n",ifontb);
			p14.add(chunk12)
			document.add(p14);
			
			Paragraph p15 =new Paragraph("", ufont)
			p15.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk13 = new Chunk("öõø¶þ´øÏ ªî°îì/Miscellaneous charges total = ${fcost}\n",ifontb);
			p15.add(chunk13)
			document.add(p15);
			Paragraph p16 =new Paragraph("\n\n\n", ufont)
			document.add(p16);
			PdfPTable table0 = new PdfPTable(2.0f,2.0f,5.0f);
			table0.setWidthPercentage(100);
			PdfPTable table1 = new PdfPTable(2.0f,2.0f,5.0f);
			table1.setWidthPercentage(100);
			
			
			
			table0.addCell("Date")
			table0.addCell("Description")
			table0.addCell("Amount")
			document.add(table0);
			// step 5
			
			
			println("Document Closed")
			
			expList.each {
				table1.addCell(it.GGE_DATE as String);
				table1.addCell(it.GGE_DESCRIPTION as String);
				table1.addCell(it.GGE_AMOUNT as String);
				
			}
			document.add(table1);
			
			Paragraph p17 =new Paragraph("", ufont)
			p17.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk18 = new Chunk("\n\n ´úøÌîÏ¶úþ´øÏ / Caretaker\n ¤ï»îï¾î ¬îùÙ / Guest House",ifontb);
			p17.add(chunk18)
			document.add(p17);
			
			
			document.close()
			println("Document Closed")
			
			
			
			OutputStream os = response.getOutputStream();
			
			PdfReader reader = new PdfReader( baos.toByteArray() )
			PdfStamper stamp = new PdfStamper( reader, os)
			
			// properties
			//PdfContentByte over;
			Rectangle pagesize;
			float x, y;
		
			try{
			  ( 1..reader.numberOfPages ).each{ int page ->
				  PdfContentByte under = stamp.getUnderContent(page);
				  
				  Font f = new Font(FontFamily.HELVETICA, 60);
				 /* Phrase p4 = new Phrase("This watermark is added UNDER the existing content", f);
				  ColumnText.showTextAligned(under, Element.ALIGN_CENTER, p4, 297, 550, 0);
				  PdfContentByte over = stamp.getOverContent(page);
				  p4 = new Phrase("This watermark is added ON TOP OF the existing content", f);
				  ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 500, 0);*/
				  
				  pagesize = reader.getPageSizeWithRotation(page);
				  x = (pagesize.getLeft() + pagesize.getRight()) / 2;
				  y = (pagesize.getTop() + pagesize.getBottom()) / 2;
				  
				
				   PdfContentByte over = stamp.getOverContent(page);
				  over.saveState();
				  PdfGState gs1 = new PdfGState();
				  gs1.setFillOpacity(0.5f);
				  over.setGState(gs1);
				  //ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 450, 0);
				  ColumnText.showTextAligned(over, Element.ALIGN_CENTER, ph, x, y, 45);
				  over.restoreState();
			
			  }
			}finally{
		
			  stamp.close()
			  
			  reader.close();
			 
			}
	}
	public PdfPCell createCell(String content, int colspan, int rowspan, int border) {
		BaseFont ihnd = BaseFont.createFont("web-app/fonts/DVBIYG3NT.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
		Font ifont=new Font(ihnd,12,Font.NORMAL,new BaseColor(0,0,0));
		Font ifontb=new Font(ihnd,12,Font.BOLD,new BaseColor(0,0,0));
	
		PdfPCell cell = new PdfPCell(new Phrase(content, ifont));
		cell.setColspan(colspan);
		cell.setRowspan(rowspan);
		cell.setBorder(border);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		return cell;
}
	
	def printRequisitionApp(){
		def req = Requisition.createCriteria()
		def reqList = req.list{
			
			eq("id",params.rid as long)
	
		}
		
		def g = Guest.createCriteria()
		def gList=g.list{
			and{
				eq("GG_REQ_ID",params.rid as int)
				//eq("GG_STATUS","data entered")
				eq("id",params.gid as long)
			}
		}
		
		def fa =Family.createCriteria()
		def fList=fa.list{
			eq("GF_GID",params.gid as int)
		}
		
		println "gList==="+gList
		float left = 30;
		float right = 30;
		float top = 60;
		float bottom = 0;
			def document = new Document(PageSize.A4, left, right, top, bottom)
			//println("Document Created")
			
			// step 2
			//PdfWriter.getInstance(document, new FileOutputStream("TaCash111.pdf"))
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PdfWriter.getInstance(document, baos);
			//println("PdfWriter Created")
			

			
			
			// step 3
			document.open()
			BaseFont ihnd = BaseFont.createFont("web-app/fonts/DVBIYG3NT.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font ifont=new Font(ihnd,14,Font.NORMAL,new BaseColor(0,0,0));
				Font ifontb=new Font(ihnd,14,Font.BOLD,new BaseColor(0,0,0));
				
			BaseFont uhnd = BaseFont.createFont("web-app/fonts/ARIALUNI.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				// for green Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(50,205,50));
				Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(0,0,0));
			BaseFont tnr = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font tnrf=new Font(tnr,12,Font.NORMAL,new BaseColor(50,0,50));
				
				BaseFont tnrb = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font tnrfb=new Font(tnrb,12,Font.BOLD,new BaseColor(50,0,50));
				
			BaseFont fs = BaseFont.createFont("web-app/fonts/FreeSans.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font fsf=new Font(fs,12,Font.NORMAL,new BaseColor(50,205,50));
		
				
				
		
		/*Paragraph p2 = new Paragraph("Ëî÷Ñî Òîú»îÆî/OFG. PAY	¤ï»îïÏ©»î Òîú»îÆîÒîùïÁ/ADL.INC	ËîÙë¬îî¥ì Êî¼îî/D. A. ÇîïÏÒîÙÆî ËîÙë¬îî¥ì Êî¼îî/TRAN DA",ifont)
		document.add(p2);*/
		
			
			println("Document Closed")
			
			PdfPTable table13 = new PdfPTable(16);
			table13.setWidthPercentage(100);
			table13.addCell(createCell("´èø.Öîë./ SI NO.", 1, 1, PdfPCell.BOX));
			table13.addCell(createCell("ÆîîËî(//´õøËî.)/ Name(Shri./Smt./Kum)", 3, 1, PdfPCell.BOX));
			table13.addCell(createCell("Çîõ./Ö½îó/M/F", 1, 1, PdfPCell.BOX));
			table13.addCell(createCell("Çî¿åÆîîËî/Design.", 3, 1, PdfPCell.BOX));
			table13.addCell(createCell("ÇîèÊîî¬î/Division", 3, 1, PdfPCell.BOX));
			table13.addCell(createCell("¥´øî¥ì/ Unit", 3, 1, PdfPCell.BOX));
			table13.addCell(createCell("Çî»îî/ Address", 3, 1, PdfPCell.BOX));
			document.add(table13);
		
			PdfPTable table14= new PdfPTable(16);
			table14.setWidthPercentage(100);
				def i=1
			gList.each {
				
				
				table14.addCell(createCell("${i}", 1, i, PdfPCell.BOX));
				table14.addCell(createCell("${it.GG_NAME}", 3, i, PdfPCell.BOX));
				
				table14.addCell(createCell("${it.GG_GENDER}", 1, i, PdfPCell.BOX));
				table14.addCell(createCell("${it.GG_DESGN}", 3, i, PdfPCell.BOX));
				table14.addCell(createCell("${it.GG_DIV}", 3, i, PdfPCell.BOX));
				table14.addCell(createCell("${it.GG_UNIT}", 3, i, PdfPCell.BOX));
				table14.addCell(createCell("${it.GG_ADDRESS}", 3, i, PdfPCell.BOX));
				i=i+1
				
			}
		
			document.add(table14);
			
			
			PdfPTable table15 = new PdfPTable(16);
			table15.setWidthPercentage(100);
			table15.addCell(createCell("¤ÒîïÅî/Duration", 3, 2, PdfPCell.BOX));
			table15.addCell(createCell("ï¿Æî/Days", 3, 2, PdfPCell.BOX));
			table15.addCell(createCell("ÇîèÌîîú²îÆî/Purpose", 3, 2, PdfPCell.BOX));
			table15.addCell(createCell(" ", 7, 2, PdfPCell.BOX));
			
			document.add(table15);
			
			PdfPTable table16= new PdfPTable(16);
			table16.setWidthPercentage(100);
			i=1
			gList.each {
				
				
				table16.addCell(createCell("${it.GG_FROM_DT} to ${it.GG_TO_DT}", 3, i, PdfPCell.BOX));
				table16.addCell(createCell("${it.GG_NO_OF_DAYS}", 3, i, PdfPCell.BOX));
				
				table16.addCell(createCell("${it.GG_PURPOSE}", 3, i, PdfPCell.BOX));
				table16.addCell(createCell(" ",7, i, PdfPCell.BOX));
				i=i+1
				
			}
		
			document.add(table16);
			Paragraph p15 =new Paragraph("", ufont)
			p15.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk13 = new Chunk("¤ÒîïÅî/Payment will be made by:",ifont);
			p15.add(chunk13)
			document.add(p15);
			PdfPTable table17 = new PdfPTable(16);
			table17.setWidthPercentage(100);
			
			table17.addCell(createCell("Goverment pays for:", 8, 2, PdfPCell.BOX));
			table17.addCell(createCell("Guest Pays for:", 8, 2, PdfPCell.BOX));
			document.add(table17);
			
			PdfPTable table18= new PdfPTable(16);
			table18.setWidthPercentage(100);
			i=1
			gList.each {
				
				table18.addCell(createCell("${it.GG_GOV_PAY_FOR}", 8, i, PdfPCell.BOX));
				table18.addCell(createCell("${it.GG_GUEST_PAY_FOR}", 8, i, PdfPCell.BOX));
				
				i=i+1
				
			}
			
			
			document.add(table18);
			Paragraph p17 =new Paragraph("", ufont)
			p17.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk17 = new Chunk("\n",ifont);
			p17.add(chunk17)
			document.add(p17);
			
			PdfPTable table19= new PdfPTable(16);
			table19.setWidthPercentage(100);
			
			table19.addCell(createCell("¤ÆîõÏîúÅî´ø»îîì ¤ïÅî´øîÏó ´øî ïÒîÒîÏºî/Details of officer Making the request:", 6, 2, PdfPCell.BOX));
			table19.addCell(createCell("ÙÖ»îîàîÏ/Signature:", 4, 2, PdfPCell.BOX));
			table19.addCell(createCell(" ", 6, 2, PdfPCell.BOX));
			
			document.add(table19);
			
			PdfPTable table20= new PdfPTable(16);
			table20.setWidthPercentage(100);
			
			table20.addCell(createCell("ÆîîËî/Name:${reqList.GR_NAME.pop()} ", 6, 2, PdfPCell.BOX));
			table20.addCell(createCell("Çî¿åÆîîËî/Design.:${reqList.GR_DESGN.pop()}", 4, 2, PdfPCell.BOX));
			table20.addCell(createCell("ÇîÙ°îîÆî Çî½î/I-card no:${} ", 6, 2, PdfPCell.BOX));
			
			
			document.add(table20);
			
			PdfPTable table21= new PdfPTable(16);
			table21.setWidthPercentage(100);
			
			table21.addCell(createCell("ïÒîÖ»îîÏ Öîë./EXTN NO.:${reqList.GR_EXTN_NO.pop()} ", 6, 2, PdfPCell.BOX));
			table21.addCell(createCell("ÇîèÊîî¬î/Division.:${reqList.GR_DIV.pop()}", 4, 2, PdfPCell.BOX));
			table21.addCell(createCell("¥´øî¥ì/Unit:", 3, 2, PdfPCell.BOX));
			table21.addCell(createCell("VECC ,Kolkata", 3, 2, PdfPCell.BOX));
			
			document.add(table21);
			
			PdfPTable table22= new PdfPTable(16);
			table22.setWidthPercentage(100);
			
			table22.addCell(createCell("¿õÏÊîîÕî Öîë./TEL NO.:${reqList.GR_TEL_NO.pop()}            ", 6, 2, PdfPCell.BOX));
			table22.addCell(createCell("öûø©Öî /FAX NO.:${reqList.GR_FAX_NO.pop()}      ", 10, 2, PdfPCell.BOX));
			
			document.add(table22);
			
			
			
			PdfPTable table24= new PdfPTable(16);
			table24.setWidthPercentage(100);
			
			table24.addCell(createCell("ËîîúÉîî¥ìÑî Öîë./MOB NO.:${reqList.GR_MOB_NO.pop()}            ", 6, 2, PdfPCell.BOX));
			table24.addCell(createCell("¥ì-ËîúÑî ¤î¥ì¸þó/E-mail id.:${reqList.GR_EMAIL_ID.pop()}      ", 10, 2, PdfPCell.BOX));
			
			document.add(table24);
			
			Paragraph p29 =new Paragraph("Approval of head of Division/Director, Group for Payment from Personnel or Goverment Account",ifontb);
			p29.setAlignment(Element.ALIGN_LEFT);
			document.add(p29);
			Paragraph p24 =new Paragraph("1.ÌîÙ ÇîèËîîïºî»î ï´øÌîî ²îî»îî Ùû ï´ø ¦âÇîÏ ¦ïÑÑîïªî»î ¤ïÅî´øîÏó /¤ï»îï¾î ÖîÏ´øîÏ /ÒÌîï©»î¬î»î ï´ø ¤îûÏ Öîú •þÙÏî§ ¬î§ Ùû|It is certified you that the stay of above mentioned office/guests are official personnel\n2.ÌîÙ Êîõ¬î»îîÆî ÖîÏ´øîÏó /ÒÌîï©»î¬î»î ªîî»îú Öîú ï´øÌîî ²îî§¬îî/The payment may be made from goverment personnel account.\n3.ÌîÙ Êîõ¬î»îîÆî ____________ (ÇîèÊîî¬î/¤ÆîõÊîî¬î) ´úø ÆîîËî ¯îÑîî ²îî§|The Payment may be debited to _______________________(Division/Group) ,BARC.\n 4.¥Öîú ïÆîËÆîïÑîïªî»î ÑîúªîîÓîóÕîì Öîë. ´úø ÆîîËîú ¸þîÑîî ²îî§(Êîî. Çî. ¤. ´úüø¿è ´úø ¤ÑîîÒîî ¤ÆÌî ¥´øî¥Ìîîú ´úø ïÑî§)|/This may be debited to the under mentioned Head of Account No. (For units other than BARC) ",ifont)
			p24.setAlignment(Element.ALIGN_LEFT);
			document.add(p24)
			document.add(new Paragraph(""));
			
			
			PdfPTable table25= new PdfPTable(16);
			table25.setWidthPercentage(100);
			
			table25.addCell(createCell("ÇîèÊîî¬îîÅÌîàî/Òî¬îì ïÆî¿úÓî´ø ¤¾îÒîî ÖîàîËî ÇîèîïÅî´øîÏó ´úø ÙÖ»îîàîÏ \n Signature of Head of Division/Director of Group or Competent authority", 8, 2, PdfPCell.BOX));
			table25.addCell(createCell("", 8, 2, PdfPCell.BOX));
			
			document.add(table25);
			
			
			PdfPTable table26= new PdfPTable(16);
			table26.setWidthPercentage(100);
			
			table26.addCell(createCell("ÆîîËî/Name", 8, 2, PdfPCell.BOX));
			table26.addCell(createCell("", 8, 2, PdfPCell.BOX));
			
			document.add(table26);
			
			
			Paragraph p27 =new Paragraph("´øîÌîîìÑîÌî ´øî ËîîúÙÏ / Office Seal\n Çîèï»î/To                            ÇîèÓîîÖîïÆî´ø ¤ïÅî´øîÏó -|||/Administrative Officer-|||\nVECC,Kolkata",ifont)
			p27.setAlignment(Element.ALIGN_LEFT);
			document.add(p27)
		
			document.add(new LineSeparator(1.5f, 100, null, 10, -10));
			
			Paragraph p28 =new Paragraph("ï¶þÇÇîºîó/Note:Ìîï¿ ïÆîãÓîõÑ´ø ¤îÒîîÖî ¦ÇîÑîÉÅî ´øÏîÌîî ²îîÆîî Ùû »îîú ï¶þÖîó /¶þó§ÖîÖîó Ìîî ÖîëÉîëïÅî»î Òî¬îìÉîîú¸þ ´úø ´øîÌîìïÒîè»î ´úø ¦ÁÏºî ï´ø Çîèï»îïÑîïÇî ÖîëÑî¬Æî ´øÏÆîó Ùîú¬îó/nIf free accomodation is to be provided, a copy of extracts of minutes of TC/TSc or concerned Group Board is to be enclosed.\n2.ÖîÏ´øîÏó Êîõ¬î»îîÆî ïÆîãÓîõÑ´ø ¤îÒîîÖî ´úø ËîîËîÑîú Ëîú ÖîÏ´øîÏó ªîî»îú Öîú Êîõ¬î»îîÆî Ùú»îõ ÇîèÊîî¬îîÅÌîàî/Òî¬îì ïÆî¿úÓî´ø ´øî ¤ÆîõËîîú¿Æî ¤ïÆîÒîîÌîì Ùû/ Approval of head of Division/director of the Group for payment from Goverment account is mandatory in the case of goverment payment/free accomodation\n3.Ìîï¿ ÇîÙÑîú Öîú ¤îÏàºî ÆîÙó ´øÏîÌîî ¬îÌîî Ùû »îîú ïÒîÓîúÕî Çîè´øîÏ ´øî ¤îÒîîÖî (ÈÑîû¶þÑîú¶þ,§´øÑî §Öîó ´øàî ¤îï¿) ÖîõïÆîïÓ°î»î ÆîÙó ï´øÌîî ²îî Öî´ø»îî/Specific type of accomodation (Flatlet ,single AC room,etc.) cannot be concerned unless advance reservation is made.",ifont);
			p28.setAlignment(Element.ALIGN_LEFT);
			document.add(p28)
			
			
			Paragraph p30 =new Paragraph("ÒîûÌîï©»î´ø / ï°îï´ø»Öîî ¤îÅîîÏ ÇîÏ ´øËîì°îîïÏÌîîú ¤îûÏ ÇîïÏÒîîÏ Öî¿ÖÌîîú Ùú»îõ ¤îÒîîÖî ´úø ïÑî§ ¤îÒîú¿Æî\nAPPLICATION FOR ACCOMODATION FOR EMPLOYEE AND FAMILY MEMBERS ON PERSONAL/MEDICAL GROUND\n\n",ifontb)
			p30.setAlignment(Element.ALIGN_LEFT);
			document.add(p30)
			
			PdfPTable table27= new PdfPTable(16);
			table27.setWidthPercentage(100);
			
			table27.addCell(createCell("ÆîîËî/Name of Employee", 4, 2, PdfPCell.BOX));
			table27.addCell(createCell("Çî¿åÆîîËî/Designation", 3, 2, PdfPCell.BOX));
			table27.addCell(createCell("/Employee NO.", 5, 2, PdfPCell.BOX));
			table27.addCell(createCell("ÇîèÊîî¬î/Division", 2, 2, PdfPCell.BOX));
			table27.addCell(createCell("¥´øî¥ì/Unit", 2, 2, PdfPCell.BOX));
			
			document.add(table27);
			
			Paragraph p31 =new Paragraph("Following persons required to stay in Hostel:                  Date: ${gList.GG_TO_DT.pop()}\n\n",ifont);
				p31.setAlignment(Element.ALIGN_LEFT);
				document.add(p31)
				
			
			PdfPTable table28= new PdfPTable(16);
			table28.setWidthPercentage(100);
			
			table28.addCell(createCell("´èø.Öîë./SL no.", 1, 2, PdfPCell.BOX));
			table28.addCell(createCell("ÆîîËî/Name", 3, 2, PdfPCell.BOX));
			table28.addCell(createCell("Çîõ./Ö½îó/M/F", 1, 2, PdfPCell.BOX));
			table28.addCell(createCell("Çî»îî/Address", 3, 2, PdfPCell.BOX));
			table28.addCell(createCell("´øËîì°îîÏó ´úø Öîî¾î ÖîëÉîëÅî/Relation with Employee", 2, 2, PdfPCell.BOX));
			table28.addCell(createCell("ÇîÙ°îîÆî Çî½î ÖîîàÌî /ID card proof", 3, 2, PdfPCell.BOX));
			table28.addCell(createCell("ÇîèÌîîú²îÆî ´øî ïÒîÒîÏºî/Purpose Details", 3, 2, PdfPCell.BOX));
			document.add(table28);
			PdfPTable table29= new PdfPTable(16);
			table29.setWidthPercentage(100);
			i=1
			fList.each {
				
				table29.addCell(createCell("${i}", 1, i, PdfPCell.BOX));
				table29.addCell(createCell("${it.GF_NAME}", 3, i, PdfPCell.BOX));
				table29.addCell(createCell("${it.GF_GENDER}", 1, i, PdfPCell.BOX));
				table29.addCell(createCell("${gList.GG_ADDRESS.pop()}", 3, i, PdfPCell.BOX));
				table29.addCell(createCell("${it.GF_REL_WITH_EMP}", 2, i, PdfPCell.BOX));
				table29.addCell(createCell("${it.GF_ID_TYPE} : ${it.GF_ID_NO}", 3, i, PdfPCell.BOX));
				table29.addCell(createCell("${gList.GG_PURPOSE.pop()}", 3, i, PdfPCell.BOX));
				
				i=i+1
				
			}
			
			document.add(table29);
			Paragraph p32 =new Paragraph("ÇîÙ°îîÆî Çî½î ÖîîàÌî -1)Öîó §°î §Öî §Öî ´øî¸ìþ ´øî ²îóÏîú©Öî 2) ïÒîÅÌîî¾îóì ´øî¸ìþ 3) ¤îÅîîÏ ´øî¸ìþ 4)°îõÆîîÒî ´øî¸ìþ 5) ÏîÓÆî ´øî¸ìþ 6)¸êþî¥ìðÒî¬î Ñîî¥ìÖîúÆÖî 7) ÇîûÆî ´øî¸ìþ 8) ÇîûüÓîÆîÏ ´øî¸ìþ (´ùø¡çÇÌîî ¥ÆîËîú Öîú ï´øÖîó ´ø ï²îÏîú©Öî ÖîÑîë¬Æî ´øÏúü)\nID Proof: 1) CHSS Card Xerox 2) Student I-Card 3) Aadhar card 4)Ration card 5) Election Card 6) Driving License 7) PAN Card 8) Pensioner's I-Card (Please enlose any one of these Xerox copy) \n\n",ifont);
			p32.setAlignment(Element.ALIGN_LEFT);
			document.add(p32)
			
			Paragraph p33 =new Paragraph("Êîõ¬î»îîÆî ï´øÌîî ²îî§¬îî ´úø ÄîÏî /Payment will be made by:___________________________ ",ifont);
			p33.setAlignment(Element.ALIGN_LEFT);
			document.add(p33)
			
			Paragraph p34 =new Paragraph("ÖîËî¾îìÆî ¿Ö»îîÒîú²î ÖîÑîë¬Æî(ÇîèÌîîú²îÆî)/Supporting document enclosed(purpose):______________________\n\n",ifont);
			p34.setAlignment(Element.ALIGN_LEFT);
			document.add(p34)
			
			PdfPTable table30= new PdfPTable(11);
			table30.setWidthPercentage(100);
			
			table30.addCell(createCell("¤ÒîïÅî/Duration  Öîú From  »î´ø  To", 5, 2, PdfPCell.BOX));
			table30.addCell(createCell("ï¿Æîîú ´øó ÖîëªÌîî/No Of Days", 3, 2, PdfPCell.BOX));
			table30.addCell(createCell("ïÒîÒîÏºî/Details", 3, 2, PdfPCell.BOX));
			
			document.add(table30);
			
			PdfPTable table31= new PdfPTable(11);
			table31.setWidthPercentage(100);
			i=1
			/*gList.each {
				
				table31.addCell(createCell("${it.GG_FROM_DT} to ${it.GG_TO_DT}", 5, i, PdfPCell.BOX));
				table31.addCell(createCell("${it.GF_NAME}", 3, i, PdfPCell.BOX));
				table31.addCell(createCell("${it.GF_GENDER}", 3, i, PdfPCell.BOX));
				
				
				//i=i+1
				
			//}*/
				table31.addCell(createCell("${gList.GG_FROM_DT} to ${gList.GG_TO_DT}", 5, i, PdfPCell.BOX));
				table31.addCell(createCell("${gList.GG_NO_OF_DAYS}", 3, i, PdfPCell.BOX));
				table31.addCell(createCell("${}", 3, i, PdfPCell.BOX));
			
			document.add(table31);
			
			Paragraph p35 =new Paragraph("¤ÆîõÏîúÅî´ø»îîì ´øËîì°îîÏó/ÇîõÒîì ´øËîì°îîÏó ´úø ïÒîÒîÏºî/Details of Employee /ex-employee making the request\n",ifontb);
			p35.setAlignment(Element.ALIGN_LEFT);
			document.add(p35)
			
			
			Paragraph p36 =new Paragraph("", ufont);
			p36.setAlignment(Element.ALIGN_LEFT);
			
			Chunk chunk36 = new Chunk("ÆîîËî/Name: ${reqList.GR_NAME.pop()}",ifont);
			p36.add(chunk36)
			Chunk chunk37 = new Chunk("        Çî¿åÆîîËî/Design/Ex: ${reqList.GR_DESGN.pop()}",ifont);
			p36.add(chunk37)
			Chunk chunk38 = new Chunk("ÙÖ»îîàîÏ/Sign:_____________________ (InService/Retired)",ifont);
			p36.add(chunk38)

			document.add(p36);
			
			Paragraph p37=new Paragraph("", ufont);
			p37.setAlignment(Element.ALIGN_LEFT);
			
			Chunk chunk39 = new Chunk("ÇîèÊîî¬î/Division: ${reqList.GR_DIV.pop()}",ifont);
			p37.add(chunk39)
			Chunk chunk40 = new Chunk("                     ¥´øî¥ì/Unit: VECC KOLKATA}",ifont);
			p37.add(chunk40)
			
			document.add(p37);
			
			Paragraph p38 =new Paragraph("", ufont);
			p38.setAlignment(Element.ALIGN_LEFT);
			
			Chunk chunk41 = new Chunk("´øîÌîîìÑîÌî ïÒîÖ»îîÏ Öîë/Office Extn No.:${reqList.GR_EXTN_NO.pop()}",ifont);
			p38.add(chunk41)

			Chunk chunk42 = new Chunk("                     öûø©Öî/Fax No.: ${reqList.GR_FAX_NO.pop()}",ifont);
			p38.add(chunk42)
		

			document.add(p38);
			
			Paragraph p39 =new Paragraph("", ufont);
			p39.setAlignment(Element.ALIGN_LEFT);
			
			Chunk chunk43 = new Chunk(" öøîúÆî/Mobile No.: ${reqList.GR_MOB_NO.pop()}",ifont);
			p39.add(chunk43)

			Chunk chunk44 = new Chunk("                     ¥ì-ËîúÑî ¤î¥ì¸þó /E-mail Id: ${reqList.GR_EMAIL_ID.pop()}\n\n\n\n\n\n\n\n\n\n\n\n",ifont);
			p39.add(chunk44)
		

			document.add(p39);
			
			Paragraph p1 =new Paragraph("", ufont)
			p1.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk1 = new Chunk("¦ï°î»î ËîîÅÌîËî ÄîÏî ¤¬îèúïÕî»î\n Forwaded Through Proper Channel\n\n (´úøÒîÑî ÖîúÒîÏ»î ´øîñËî´øîú Ùú»îõ Ñîî¬îõ Applicable only for serving personal)",ifontb);
			chunk1.setUnderline(1.5f, -5.0f);
			p1.add(chunk1)
			document.add(p1);
			
			
			Paragraph p45 =new Paragraph("ÌîÙ ÖîëÖ»îõï»î ï´ø ²îî»îó Ùû ¦ÇîÏîú©»î ¥ëï¬î»î ¤ïÅî´øîÏó /´øËîì°îîÏó Æîú ¤ÇîÆîú ÇîïÏÒîîÏ ´úø Öî¿ÖÌîîú ´úø ïÑî§ ¤îÒîîÖî ´øî ¤ÆîõÏîúÅî ÇîõÏó »îÏÙ ÒîûÌîï©»î¬î»î /ï°îï´ø»Öîî ¤îÅîîÏ ÇîÏ ï´øÌîî Ùû\nIt is recommended that the above mentioned opfficer /employee has requested accomodation for his family member on purely Personal/medical ground\n\n", ifont);
			p45.setAlignment(Element.ALIGN_LEFT);
			document.add(p45);
			
			
			PdfPTable table46= new PdfPTable(16);
			table46.setWidthPercentage(100);
			
			table46.addCell(createCell("ÇîèÊîî¬îîÅÌîàî ÖîàîËî ÇîèîïÅî´øîÏó ´úø ÙÖ»îîàîÏ/Sign Of Head Of Division/Competent Authority", 8, 2, PdfPCell.BOX));
			table46.addCell(createCell("", 8, 2, PdfPCell.BOX));
			document.add(table46);
			
			PdfPTable table47= new PdfPTable(16);
			table47.setWidthPercentage(100);
			
			table47.addCell(createCell("´øîÌîîìÑîÌî ´øî ËîîúÙÏ /Office Seal                                                            ", 8, 2, PdfPCell.BOX));
			table47.addCell(createCell("", 8, 2, PdfPCell.BOX));
			document.add(table47);
			
			Paragraph p48 =new Paragraph("Çîèï»î/To\nÇîèÓîîÖîÆî ¤ïÅî´øîÏó /Administrative Officer -|||\n ÇîèïÓîàîºî ïÒîÅîîÑîÌî ±þî½îîÒîîÖî/Training School Hostel\n\n", ifont);
			p48.setAlignment(Element.ALIGN_LEFT);
			document.add(p48);
			
			PdfPTable table = new PdfPTable(4);
			PdfPCell cell = new PdfPCell(new Phrase("Approved"));
			table.addCell(cell);
			
			PdfPCell cell23 = new PdfPCell(new Phrase("sign"));
			cell23.setColspan(10);
			cell23.setRowspan(5);
			table.addCell(cell23);
			cell = new PdfPCell(new Phrase("Registered"));
			table.addCell(cell);
			
			document.add(table);
			
			
			
			
			
			Paragraph p49 =new Paragraph("ï¶þÇÇîºîó/Note\n\n", ifont);
			p49.setAlignment(Element.ALIGN_LEFT);
			document.add(p49);
			
			Paragraph p50 =new Paragraph("1.ïÒîÕîúÓî Çîè´øîÏ ´úø ¤îÒîîÖî (ÇÑîû¶þ –Ñîú¶þ,§´øÑî §Öîó ,¥»Ìîîï¿) ´øî ¤îÓîÒîîÖîÆî ÆîÙô ï¿Ìîî ²îî Öî´ø»îî|\n1.Specific type of accomodation (Flat-let,Single Ac,etc) cannot assured.\n2.ÖîÏ´øîÏó Éîõð´ø¬î Ùú»îõ »î»î´øîÑî ¤îÒîÓÌî´ø»îî ÙîúÆîú ÇîÏ ÖîàîËî ÇîèîïÅî´øîÏó ÄîÏî ´øàî ´øî ¤îÏàîºî Ï¿ ï´øÌîî ²îî Öî´ø»îî Ùû|\n2.Competent Authority can cancel the room reservation in casev of any urgent need for official booking\n3.Ìîï¿ ´øËîì°îîÏó ¤ï»îï¾î ÄîÏî ÖîÏ´øîÏó ÖîËÇî¿î ´øîú ï´øÖîó Çîè´øîÏ ´øó ÙîïÆî /àîï»î Ùîú»îó Ùû, »îîú ¦Öî´øî Çî÷Ïî Ëî÷ÑÌî ´øËîì°îîïÏÌîîú/¤ï»îï¾îÌîîú Öîú ÒîÖî÷Ñî ï´øÌîî ²îî§¬îî|\n3.In case of any damage/loss to Govt. property occured by employees/guests the full cost will be recovered from employee/guest.4.´ùø¡çÇÌîî ïÒîÒîÏºî ´úø ¤ë»î¬îì»î Ìîî½îî ´øî ÇîèÌîîú²îÆî ÖÇîÕ¶þ ÐøÇî Öîú ïÑîªîúü|\n4.Please specify rthe purpose of visit clearly under details\n5. ¤îÒîÓÌî´ø Ëîî¬îì¿ÓîìÆî ´úø ïÑî§ ¤¬îÑîî Çîù¡çÕ¶þ ¿úªîúü|\n5.For necessary guidelines see overleaf\n", ifont);
			p50.setAlignment(Element.ALIGN_LEFT);
			document.add(p50);
			
			
			
			
			document.close()
			println("Document Closed")
			
			
			
			OutputStream os = response.getOutputStream();
			
			PdfReader reader = new PdfReader( baos.toByteArray() )
			PdfStamper stamp = new PdfStamper( reader, os)
			
			// properties
			//PdfContentByte over;
			Rectangle pagesize;
			float x, y;
		
			try{
			  ( 1..reader.numberOfPages ).each{ int page ->
				  PdfContentByte under = stamp.getUnderContent(page);
				  
				  Font f = new Font(FontFamily.HELVETICA, 60);
				 /* Phrase p4 = new Phrase("This watermark is added UNDER the existing content", f);
				  ColumnText.showTextAligned(under, Element.ALIGN_CENTER, p4, 297, 550, 0);
				  PdfContentByte over = stamp.getOverContent(page);
				  p4 = new Phrase("This watermark is added ON TOP OF the existing content", f);
				  ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 500, 0);*/
				  
				  pagesize = reader.getPageSizeWithRotation(page);
				  x = (pagesize.getLeft() + pagesize.getRight()) / 2;
				  y = (pagesize.getTop() + pagesize.getBottom()) / 2;
				  
				
				   PdfContentByte over = stamp.getOverContent(page);
				  over.saveState();
				  PdfGState gs1 = new PdfGState();
				  gs1.setFillOpacity(0.5f);
				  over.setGState(gs1);
				  //ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 450, 0);
				  ColumnText.showTextAligned(over, Element.ALIGN_CENTER, ph, x, y, 45);
				  over.restoreState();
			
			  }
			}finally{
		
			  stamp.close()
			  
			  reader.close();
			 
			}
		
		
			
		
	}
	
	
	
	
	
	def requisitionHome(){
		
		def req = Requisition.createCriteria()
		def reqList = req.list{
	  
			eq("GR_PERID",session.PERID as int)
	
		}
		
		/*def guest = Guest.createCriteria()
		 def guestList = guest.list{
		 
			 and{
			 eq("GG_REQ_ID",reqList.id.pop() as int)
			 ne("GG_STATUS","data entered")
			 }
		 
		 }*/
		 
		
			if(reqList)
			{
				def r = reqList.id.pop() as long
				def sql=new Sql(dataSource)
				def guestList =sql.rows("select GG_ID,GG_NAME,GG_REQ_ID,GG_STATUS,GG_DESGN,GG_DIV,GG_UNIT,GG_ADDRESS,GB_ID,GB_GID,GB_BILL_STATUS,GB_DATE,GB_AMOUNT,GB_DESC from VECUSR.GH_GUEST LEFT OUTER JOIN VECUSR.GH_BILL ON GH_GUEST.GG_ID = GH_BILL.GB_GID WHERE GG_STATUS !=:stat",[stat:"data entered"])
				
				render(view:"requisitionHome.gsp",model:[guestList:guestList,reqList:reqList])
			}
			
			else{
				
				render(view:"addRequisitionDetials.gsp")
				
			}
			
		
		 
		}
 
	
	def cancelBooking(){
		
		def guestId = params.gid as int
		
		def g = Guest.get(guestId)
		g.GG_STATUS= "booking cancelled"
		g.save(flush:true,failOnError:true)
		
		def ga1= GuestArchive.createCriteria()
		def gaList = ga1.list{
			
			eq("GGA_GID",guestId)
		}
		
		def gaId = gaList.id.pop()
		def ga = GuestArchive.get(gaId)
		ga.GGA_STATUS = "booking cancelled"
		ga.save(flush:true,failOnError:true)
		
		
		def rt1 = RoomTransaction.createCriteria()
		def rtList= rt1.list{
			
			eq("GRT_GID",guestId)
		}
		
		
		def rtId = rtList.id.pop()
		def rt = RoomTransaction.get(rtId)
		rt.delete(flush:true,failOnError:true)
		
		requisitionHome()
	}
 
	
	def bookingRequest(){
		
		def g = Guest.createCriteria()
		def gList = g.list{
			
			eq("GG_STATUS","data entered")
			
		}
		
		for(item in gList){
			
			def gid = item.id as int
			
			def guest = Guest.get(gid)
			guest.GG_STATUS = "pending for booking"
			guest.save(flush:true,failOnError:true)
		}
		
		
		newRequisition()
	}
	
	
	
	
 
	def billDetailsReq(){
		
		def g = Guest.createCriteria()
		def guest=g.list{
			
			eq("id",params.gid as long)
		}
		
		
		def nod=guest.GG_NO_OF_DAYS.pop() as int
		def rf=guest.GG_ROOM_FACILITY.pop()
		def gc=guest.GG_TID.pop() as long
		def gb_or_gr=guest.GG_BED_OR_ROOM.pop()
		def no_b_or_r=guest.GG_NO_OF_BED_OR_ROOM.pop() as int
		
		def t= Tariff.createCriteria()
		def tList=t.list{
			
			eq("id",gc)
			
		}
		
		def tariff
		
		if(rf=="AC")
		{
		   tariff=tList.GT_AC_CHARGE.pop() as int
		}
		else
		{
			tariff=tList.GT_NAC_CHARGE.pop() as int
		}
		
		def lodgingCost
		
		if(gb_or_gr=="bed"){
			
			lodgingCost=no_b_or_r * tariff
		}
		else
		{
			lodgingCost=(2 * (no_b_or_r * tariff))
		}
		
		def lpd = lodgingCost
		
		lodgingCost=lodgingCost * nod
		
		def ex = GuestExpenditure.createCriteria()
		def expList=ex.list{
			
				eq("GGE_GID",params.gid as int)
			   
			
		}
		
		def x = 0
		def foodCost = 0
		if(expList){
			for (item in expList){
				
				x = item.GGE_AMOUNT as int
				foodCost = foodCost + x
				
			}
		}
		
		def totalBill = foodCost + lodgingCost
		
		render(view:"billDetailsReq.gsp",model:[guest:guest,tariff:tariff,lpd:lpd,lodgingCost:lodgingCost,expList:expList,foodCost:foodCost,totalBill:totalBill])
		
		
	}
	
	def newRequisition(){
		
		def req = Requisition.createCriteria()
		def reqList = req.list{
	  
			and{
			eq("GR_PERID",session.PERID as int)
			
			}
		}
		
		
		def guest = Guest.createCriteria()
		def guestList = guest.list{
		
			
		eq("GG_REQ_ID",reqList.id.pop() as int)
		eq("GG_STATUS","data entered")
		}
		
		
		
	render(view:"requisition.gsp", model:[guestList:guestList,reqList:reqList])
		
	}
	
	def addGuest(){
		
		render(view:"addGuest.gsp")
	
	}
	
	
	def newGuest(){
		
		def req = Requisition.createCriteria()
		def reqList = req.list{
	  
			eq("GR_PERID",session.PERID as int)
	
		}
		
		
		def t = Tariff.createCriteria()
		def tList = t.list{
			
			eq("GT_CATEGORY",params.GG_CATEGORY)
		}
		
		def TariffId = tList.id.pop() as int
		
		def x=reqList.id.pop() as int
		def g = new Guest()
		def sql=new Sql(dataSource)
		def guidl=sql.rows("select nvl(max(GG_ID),0 )+1 guid1 from GH_GUEST")
		def guid= guidl.pop().guid1
		
		
		g.id=guid as int
		g.GG_REQ_ID=x as int
		g.GG_NAME=params.GG_NAME
		g.GG_GENDER=params.GG_GENDER
		g.GG_EMAIL=params.GG_EMAIL
		
		g.GG_PHONE=params.GG_PHONE as long
		g.GG_DESGN=params.GG_DESGN
		g.GG_DIV=params.GG_DIV
		g.GG_UNIT=params.GG_UNIT
		g.GG_ADDRESS=params.GG_ADDRESS
		g.GG_STATUS="data entered"
		if(params.GG_FROM_DT)
		g.GG_FROM_DT=Date.parse('yyyy-MM-dd', (params.GG_FROM_DT))
		if(params.GG_TO_DT)
		g.GG_TO_DT=Date.parse('yyyy-MM-dd', (params.GG_TO_DT))
		g.GG_NO_OF_DAYS=params.GG_NO_OF_DAYS as int
		g.GG_BED_OR_ROOM=params.GG_BED_OR_ROOM
		g.GG_NO_OF_BED_OR_ROOM=params.GG_NO_OF_BED_OR_ROOM as int
		g.GG_CATEGORY=params.GG_CATEGORY
		g.GG_PURPOSE_DESC=params.GG_PURPOSE_DESC
		g.GG_ID_CARD_NO=params.GG_ID_CARD_NO
		g.GG_DOC=params.GG_DOC
		g.GG_NO_OF_MEM=params.GG_NO_OF_MEM as int
		g.GG_ID_CARD_TYPE=params.GG_ID_CARD_TYPE
		g.GG_ROOM_FACILITY=params.GG_ROOM_FACILITY
		g.GG_GH_TYPE=params.GG_GH_TYPE
		g.GG_PURPOSE=params.GG_PURPOSE
		g.GG_GUEST_PAY_FOR=params.GG_GUEST_PAY_FOR
		g.GG_GOV_PAY_FOR=params.GG_GOV_PAY_FOR
		if(params.GG_REQ_DT)
		g.GG_REQ_DT=Date.parse('yyyy-MM-dd', (params.GG_REQ_DT))
		g.GG_PAY_METHOD=params.GG_PAY_METHOD
		g.GG_PAYED_BY=params.GG_PAYED_BY
		g.GG_TID = TariffId
		g.save(flush:true,failOnError:true)
		
		newRequisition();
		
		
	}
	
	
	def editGuestDetails(){
		
		def guest = Guest.createCriteria()
		def guestList = guest.list{
		
			
		eq("id",params.guid as java.lang.Long )
		
		}
		
		
	render(view:"editGuest.gsp", model:[guestList:guestList])
		
	}
	
	
	
	 def editGuestSave(){
		
		
		def req = Requisition.createCriteria()
		def reqList = req.list{
	  
			eq("GR_PERID",session.PERID as int)
	
		}
		
		println"====="+params.id 
		
		
		
		
		def t = Tariff.createCriteria()
		def tList = t.list{
			
			eq("GT_CATEGORY",params.GG_CATEGORY)
		}
		
		def TariffId = tList.id.pop() as int
		
		
		def g = Guest.get(params.id)
		g.id=params.id as int
		g.GG_REQ_ID=reqList.id.pop() as int
		g.GG_NAME=params.GG_NAME
		g.GG_GENDER=params.GG_GENDER
		g.GG_EMAIL=params.GG_EMAIL
		g.GG_PHONE=params.GG_PHONE as long
		g.GG_DESGN=params.GG_DESGN
		g.GG_DIV=params.GG_DIV
		g.GG_UNIT=params.GG_UNIT
		g.GG_ADDRESS=params.GG_ADDRESS
		if(params.GG_FROM_DT)
		g.GG_FROM_DT=Date.parse('yyyy-MM-dd', (params.GG_FROM_DT))
		if(params.GG_TO_DT)
		g.GG_TO_DT=Date.parse('yyyy-MM-dd', (params.GG_TO_DT))
		g.GG_NO_OF_DAYS=params.GG_NO_OF_DAYS as int
		g.GG_BED_OR_ROOM=params.GG_BED_OR_ROOM
		g.GG_NO_OF_BED_OR_ROOM=params.GG_NO_OF_BED_OR_ROOM as int
		g.GG_CATEGORY=params.GG_CATEGORY
		g.GG_PURPOSE_DESC=params.GG_PURPOSE_DESC
		g.GG_ID_CARD_NO=params.GG_ID_CARD_NO
		g.GG_DOC=params.GG_DOC
		g.GG_NO_OF_MEM=params.GG_NO_OF_MEM as int
		g.GG_ID_CARD_TYPE=params.GG_ID_CARD_TYPE
		g.GG_ROOM_FACILITY=params.GG_ROOM_FACILITY
		g.GG_GH_TYPE=params.GG_GH_TYPE
		g.GG_PURPOSE=params.GG_PURPOSE
		g.GG_GUEST_PAY_FOR=params.GG_GUEST_PAY_FOR
		g.GG_GOV_PAY_FOR=params.GG_GOV_PAY_FOR
		if(params.GG_REQ_DT)
		g.GG_REQ_DT=Date.parse('yyyy-MM-dd', (params.GG_REQ_DT))
		g.GG_PAY_METHOD=params.GG_PAY_METHOD
		g.GG_PAYED_BY=params.GG_PAYED_BY
		g.GG_TID = TariffId
		g.save(flush:true,failOnError:true)
		
		newRequisition();
		
	}
	
	
		def delGuest(){
			
			def g=Guest.get(params.gid)
			g.delete(flush:true,failOnError:true)
			requisitionHome();
		}
		
	 def requisition(){
	 
		 render(view:"addRequisitionDetials.gsp")
		 
		 }
	 
		def addRequisitionDetails(){
		
			def r = new Requisition()
			
			def sql=new Sql(dataSource)
				def ridl=sql.rows("select nvl(max(GR_ID),0 )+1 rid1 from GH_REQUISITION")				
				def rid= ridl.pop().rid1
			
				println"===="+params.GR_NAME
				
				r.id = rid as long
				r.GR_PERID= session.PERID as int
				r.GR_NAME=params.GR_NAME
				r.GR_EXTN_NO=params.GR_EXTN_NO as int
				r.GR_TEL_NO=params.GR_TEL_NO as int
				r.GR_MOB_NO=params.GR_MOB_NO as long
				r.GR_DESGN=params.GR_DESGN
				r.GR_DIV=params.GR_DIV
				r.GR_FAX_NO=params.GR_FAX_NO as int
				r.GR_EMAIL_ID=params.GR_EMAIL_ID
				/*r.GR_SRC_PERID=params.GR_SRC_PERID  as int
				r.GR_DEST_PERID=params.GR_DEST_PERID  as int
				r.GR_APVR_PERID=params.GR_APVR_PERID as int
				r.GR_APVR_CMT=params.GR_APVR_CMT*/
				r.GR_ICARD_NO=params.GR_ICARD_NO
				r.GR_ADDRESS=params.GR_ADDRESS
				
				r.save(flush:true,failOnError:true)
				requisitionHome()
			
		
		}
		
		def family(){
			
			//println"====="+params.gid
			def g=params.gid
			def f=Family.createCriteria()
			def familyList=f.list(){
				
				eq("GF_GID",params.gid as int)
			}
			
			render(view:"family.gsp",model:[familyList:familyList,g:g])
		}
		
		def newFamily(){
			
			println"-----"+params.GF_GID
				
				def f = new Family()
				def sql=new Sql(dataSource)
				def fidl=sql.rows("select nvl(max(GF_ID),0 )+1 fid1 from GH_FAMILY")
				def fid= fidl.pop().fid1
				
				f.id=fid as int
				
				f.GF_GID=params.GF_GID as int
			
				f.GF_NAME=params.GF_NAME
				f.GF_GENDER=params.GF_GENDER
				f.GF_REL_WITH_EMP=params.GF_REL_WITH_EMP
				f.GF_ID_TYPE=params.GF_ID_TYPE
				f.GF_ID_NO=params.GF_ID_NO
				f.save(flush:true,failOnError:true)
			
				def family=Family.createCriteria()
					def familyList=family.list(){
			
					eq("GF_GID",params.GF_GID as int)
				}
				
				render(view:"family.gsp",model:[familyList:familyList])
				
			
			}
		
		def delFamily(){
			 println"fid====="+params.fid
			def f = Family.get(params.fid)
			f.delete(flush: true,failOnError:true)
			
			
			def family=Family.createCriteria()
			
		def familyList=family.list(){
			
			
				eq("GF_GID",params.guid as int)
			}
			
			render(view:"family.gsp",model:[familyList:familyList])
		}
		
		def editFamily(){
			
			def f = Family.createCriteria()
			def fEditList = f.list(){
				
				eq("id",params.fid as long)
				
			}
			
			
			render(view:"editFamily.gsp", model:[fEditList:fEditList])
			
			
		}
		
		def updateFamily(){
			
			def f = Family.get(params.id)
			f.id=params.id as long
			f.GF_GID=params.GF_GID as int
			
				f.GF_NAME=params.GF_NAME
				f.GF_GENDER=params.GF_GENDER
				f.GF_REL_WITH_EMP=params.GF_REL_WITH_EMP
				f.GF_ID_TYPE=params.GF_ID_TYPE
				f.GF_ID_NO=params.GF_ID_NO
				f.save(flush:true,failOnError:true)
			
				def family=Family.createCriteria()
					def familyList=family.list(){
			
					eq("GF_GID",params.GF_GID as int)
				}
				
				render(view:"family.gsp",model:[familyList:familyList])
		}
		
		/* def newRequisition(String obj){
			
				def j = params.GG_NO_OF_MEM as int
				def req = Requisition.createCriteria()
				def reqList = req.list{
			  
					eq("GR_PERID",session.PERID as int)
			
				}
				
				def x=reqList.id.pop() as int
				 println "===="+ x
				def g = new Guest()
				def sql=new Sql(dataSource)
				def guidl=sql.rows("select nvl(max(GG_ID),0 )+1 guid1 from GH_GUEST")				
				def guid= guidl.pop().guid1
				
				
				g.id=guid as int
				g.GG_REQ_ID=x as int
				g.GG_NAME=params.GG_NAME
				g.GG_GENDER=params.GG_GENDER
				g.GG_EMAIL=params.GG_EMAIL
				
				//g.GG_PHONE=params.GG_PHONE as long
				g.GG_DESGN=params.GG_DESGN
				g.GG_DIV=params.GG_DIV
				g.GG_UNIT=params.GG_UNIT
				g.GG_ADDRESS=params.GG_ADDRESS
				g.GG_STATUS=params.GG_STATUS
				if(params.GG_FROM_DT)
				g.GG_FROM_DT=Date.parse('yyyy-MM-dd', (params.GG_FROM_DT))
				if(params.GG_TO_DT)
				g.GG_TO_DT=Date.parse('yyyy-MM-dd', (params.GG_TO_DT))
				//g.GG_NO_OF_DAYS=params.GG_NO_OF_DAYS as int
				g.GG_BED_OR_ROOM=params.GG_BED_OR_ROOM
				//g.GG_NO_OF_BED_OR_ROOM=params.GG_NO_OF_BED_OR_ROOM as int
				g.GG_CATEGORY=params.GG_CATEGORY
				g.GG_PURPOSE_DESC=params.GG_PURPOSE_DESC
				g.GG_ID_CARD_NO=params.GG_ID_CARD_NO
				//g.GG_DOC=params.GG_DOC
				g.GG_NO_OF_MEM=params.GG_NO_OF_MEM as int
				g.GG_ID_CARD_TYPE=params.GG_ID_CARD_TYPE
				g.GG_ROOM_FACILITY=params.GG_ROOM_FACILITY
				g.GG_GH_TYPE=params.GG_GH_TYPE
				g.GG_PURPOSE=params.GG_PURPOSE
				g.GG_GUEST_PAY_FOR=params.GG_GUEST_PAY_FOR
				g.GG_GOV_PAY_FOR=params.GG_GOV_PAY_FOR
				g.save()
				
				def f = new Family()
				
				def fidl=sql.rows("select nvl(max(GF_ID),0 )+1 fid1 from GH_FAMILY")
				def fid= fidl.pop().fid1
				
				f.id=fid
				f.GF_GID=guid as int
				f.GF_NAME=params.GF_NAME
				f.GF_GENDER=params.GF_GENDER
				f.GF_REL_WITH_EMP=params.GF_REL_WITH_EMP
				f.GF_ID_TYPE=params.GF_ID_TYPE
				f.GF_ID_NO=params.GF_ID_NO
				f.save()
				
				obj = params.obj
				obj= j
				
				//render "success"
				
				
				
			}*/
			
		
	  
  def roomRequest(){
	  def room = Room.createCriteria()
	  def roomList= room.list(sort : "id"){
		  
	  }
	  render(view:"room.gsp", model:[roomList:roomList])
	  
  }
  
  def room(){
	  def sql=new Sql(dataSource)
	  def gridl=sql.rows("select nvl(max(GR_ID),0 )+1 grid1 from GH_ROOM")
	  def grid= gridl.pop().grid1
	  
	  
	  render(view:"newRoom.gsp", model: [grid:grid])
	  
  }
  
  
  def newRoom(){
	  def sql=new Sql(dataSource)
	  def gridl=sql.rows("select nvl(max(GR_ID),0 )+1 grid1 from GH_ROOM")
	  def grid= gridl.pop().grid1 
	  Room r =new Room()
	  
	  r.id= grid
	  
	  r.GR_ROOM_NO = params.GR_ROOM_NO as int
	  r.GR_BED_NO = params.GR_BED_NO 
	  r.GR_TYPE = params.GR_TYPE
	  r.GR_FACILITY =params.GR_FACILITY
	  if(params.GR_RESR_FROM)
	  r.GR_RESR_FROM =Date.parse('yyyy-MM-dd', (params.GR_RESR_FROM))
	  if(params.GR_RESR_TO)
	  r.GR_RESR_TO =Date.parse('yyyy-MM-dd', (params.GR_RESR_TO))
	  r.GR_STATUS = params.GR_STATUS
	  r.save(flush:true,failOnError:true)
	  
	  roomRequest()
	 
  }
  
  
  def editRoom(){
	  
	//println "rid----"+params.rid
	  
	  def room = Room.createCriteria()
	  def roomEditList = room.list(){
		  
		  eq("id",params.rid as long)
		  
	  }
	  
	  
	  render(view:"editRoom.gsp", model:[roomEditList:roomEditList])
  }
  
  
  def updateRoom(){
	  
	  def r = Room.get(params.id)
	  
	  println"room====="+params.id
	  r.id=params.id as long
	  r.GR_ROOM_NO = params.GR_ROOM_NO as int
	  r.GR_BED_NO = params.GR_BED_NO
	  r.GR_TYPE = params.GR_TYPE
	  r.GR_FACILITY =params.GR_FACILITY
	  if(params.GR_RESR_FROM)
	  r.GR_RESR_FROM =Date.parse('yyyy-MM-dd', (params.GR_RESR_FROM))
	  if(params.GR_RESR_TO)
	  r.GR_RESR_TO =Date.parse('yyyy-MM-dd', (params.GR_RESR_TO))
	  r.GR_STATUS = params.GR_STATUS
	  r.save(flush:true,failOnError:true)
	  
	  roomRequest()
	  
  }
  
  def delRoom(){
	  
	  
	  def r=Room.get(params.rid)
	  r.delete(flush: true,failOnError:true)
	  roomRequest()
  }
  
  def tariffRequest(){
	  
	  def tar = Tariff.createCriteria()
	  def tariffList = tar.list {
		   
		   
	   }
	  
	  render(view:"tariff.gsp", model: [tariffList:tariffList])
  }
  
  def tariff()
  {
	  def sql=new Sql(dataSource)
	  def tridl=sql.rows("select nvl(max(GT_ID),0 )+1 trid1 from GH_TARIFF")
	  def trid= tridl.pop().trid1
	  
	  
	  render(view:"newTariff.gsp", model: [trid:trid])
  }
  
  def newTariff(){
	  def sql=new Sql(dataSource)
	  def tridl=sql.rows("select nvl(max(GT_ID),0 )+1 trid1 from GH_TARIFF")
	  def trid= tridl.pop().trid1
	  
	  Tariff t = new Tariff()
	  t.id=trid
	  t.GT_CATEGORY = params.GT_CATEGORY
	  t.GT_AC_CHARGE = params.GT_AC_CHARGE as int
	  t.GT_NAC_CHARGE = params.GT_NAC_CHARGE as int
	  
	  t.save(flush:true,failOnError:true)
	  tariffRequest();
  }
  
  def editTariff(){
	  
	  def t = Tariff.createCriteria()
	  def tariffEditList = t.list(){
		  
		  eq("id",params.tid as long)
		  
	  }
	  
	 
	  render(view:"editTariff.gsp", model:[tariffEditList:tariffEditList])
	
  }
  
  def updateTariff(){
	  
	def t = Tariff.get(params.id)  
	
	t.id=params.id as long
	t.GT_CATEGORY = params.GT_CATEGORY
	t.GT_AC_CHARGE = params.GT_AC_CHARGE as int
	t.GT_NAC_CHARGE = params.GT_NAC_CHARGE as int
	
	t.save(flush:true,failOnError:true)
	tariffRequest();
  }
  
  
  def delTariff(){
	  
	  def t=Tariff.get(params.tid)
	  t.delete(flush: true,failOnError:true)
	  tariffRequest()
  }
  
 def  currentGuest(){
	 
	 def sql=new Sql(dataSource)
	 def guestList =sql.rows("select GG_ID,GG_NAME,GG_STATUS,GG_ID_CARD_NO,GRT_ROOM_NO,GRT_BED_NO,GG_FROM_DT,GG_TO_DT from VECUSR.GH_GUEST INNER JOIN VECUSR.GH_ROOM_TRANSACTION ON GH_GUEST.GG_ID = GH_ROOM_TRANSACTION.GRT_GID where GG_STATUS =:gs1 OR GG_STATUS =:gs2",[gs1:"checked in",gs2:"bill paid"])
	 
	 
	 render(view:"currentGuest.gsp",model:[guestList:guestList])
	 
 }
 
 def guestExp(){
	 
	 def guestId = params.gid as long
	 def sql=new Sql(dataSource)
	 def guestList =sql.rows("select GG_ID,GG_NAME,GG_STATUS,GGE_ID,GGE_GID,GGE_DATE,GGE_DESCRIPTION,GGE_AMOUNT from VECUSR.GH_GUEST LEFT OUTER JOIN VECUSR.GH_GUEST_EXPENDITURE ON GH_GUEST.GG_ID = GH_GUEST_EXPENDITURE.GGE_GID where GG_ID =:gID ",[gID:guestId])
	 render(view:"guestExp.gsp",model:[guestList:guestList])
	 
 }
 
 
 /*def addExp(){
	 def guestId=params.gid as int
	 render(view:"addExpenditure.gsp",model:[guestId:guestId])
	 }*/
 
  def expSave(){
	  
	  def sql=new Sql(dataSource)
	  def exidl=sql.rows("select nvl(max(GGE_ID),0 )+1 exid1 from GH_GUEST_EXPENDITURE")
	  def exid= exidl.pop().exid1
	  
	  println"id======"+params.GGE_GID
	  def e=new GuestExpenditure()
	  e.id=exid as int
	  e.GGE_GID=params.GGE_GID as int
	  e.GGE_DATE=Date.parse('yyyy-MM-dd', (params.GGE_DATE))
	  e.GGE_DESCRIPTION=params.GGE_DESCRIPTION
	  e.GGE_AMOUNT=params.GGE_AMOUNT as int
	  e.save(flush:true,failOnError:true)
	  
	  
	 def guestId = params.GGE_GID as long
	 
	 def guestList =sql.rows("select GG_ID,GG_NAME,GG_STATUS,GGE_ID,GGE_GID,GGE_DATE,GGE_DESCRIPTION,GGE_AMOUNT from VECUSR.GH_GUEST LEFT OUTER JOIN VECUSR.GH_GUEST_EXPENDITURE ON GH_GUEST.GG_ID = GH_GUEST_EXPENDITURE.GGE_GID where GG_ID =:gID",[gID:guestId])
	 render(view:"guestExp.gsp",model:[guestList:guestList])
  }
  
  def todaysGuest(){
	  
	  def todayDate = new Date().clearTime()
	  def g = Guest.createCriteria()
	  def guestList= g.list{
		  
		 eq("GG_FROM_DT",todayDate)
	  }
	  
	  render(view:"todaysGuest.gsp",model:[guestList:guestList])
  }
  
  
  
  def printTodayGuest(){
	  
	  def sql=new Sql(dataSource)
	 def guestList =sql.rows("select GG_ID,GG_NAME,GG_STATUS,GG_DESGN,GG_UNIT,GG_PAY_METHOD,GG_FROM_DT,GG_TO_DT,GGA_CHECK_IN_TIME,GGA_ROOM_NO from VECUSR.GH_GUEST INNER JOIN VECUSR.GH_GUEST_ARCHIVE ON GH_GUEST.GG_ID= GH_GUEST_ARCHIVE.GGA_GID where TO_CHAR(GG_FROM_DT,'dd-MM-YYYY')=?",[new Date().format("dd-MM-YYYY")]);
	  
	 println "GG_ID"+guestList.GGA_ROOM_NO
	 
	 
	 float left = 30;
	 float right = 30;
	 float top = 60;
	 float bottom = 0;
		 def document = new Document(PageSize.A4, left, right, top, bottom)
		 //println("Document Created")
		 
		 // step 2
		 //PdfWriter.getInstance(document, new FileOutputStream("TaCash111.pdf"))
		 ByteArrayOutputStream baos = new ByteArrayOutputStream();
		 PdfWriter.getInstance(document, baos);
		 //println("PdfWriter Created")
		 

		 
		 
		 // step 3
		 document.open()
		 BaseFont ihnd = BaseFont.createFont("web-app/fonts/DVBIYG3NT.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			 Font ifont=new Font(ihnd,14,Font.NORMAL,new BaseColor(0,0,0));
			 Font ifontb=new Font(ihnd,14,Font.BOLD,new BaseColor(0,0,0));
			 
		 BaseFont uhnd = BaseFont.createFont("web-app/fonts/ARIALUNI.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			 // for green Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(50,205,50));
			 Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(0,0,0));
		 BaseFont tnr = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			 Font tnrf=new Font(tnr,12,Font.NORMAL,new BaseColor(50,0,50));
			 
			 BaseFont tnrb = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			 Font tnrfb=new Font(tnrb,12,Font.BOLD,new BaseColor(50,0,50));
			 
		 BaseFont fs = BaseFont.createFont("web-app/fonts/FreeSans.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			 Font fsf=new Font(fs,12,Font.NORMAL,new BaseColor(50,205,50));
	 
			 
			 
	 
	 /*Paragraph p2 = new Paragraph("Ëî÷Ñî Òîú»îÆî/OFG. PAY	¤ï»îïÏ©»î Òîú»îÆîÒîùïÁ/ADL.INC	ËîÙë¬îî¥ì Êî¼îî/D. A. ÇîïÏÒîÙÆî ËîÙë¬îî¥ì Êî¼îî/TRAN DA",ifont)
	 document.add(p2);*/
	 
		 
		
			
			 Paragraph p15 =new Paragraph("", ufont);
			 p15.setAlignment(Element.ALIGN_CENTER);
			 Chunk chunk13 = new Chunk("ÊîîÏ»î ÖîÏ´øîÏ/Goverment Of India\n ÇîÏËîîÆîõ ¦²îîì ïÒîÊîî¬î/Department of Atomic Energy\nÇîïÏÒî»îóì ¦²îîì Öîî¥©Ñîîú¶þîýÆî ´úøÆ¿èþ/Variable Cyclotron centre\n",ifont);
			 p15.add(chunk13);
			 document.add(p15);
			 
			 
			 Paragraph p24 =new Paragraph("", ufont);
			 p24.setAlignment(Element.ALIGN_RIGHT);
			 Chunk chunk24 = new Chunk("1/A.F. Bidhan Nagar , Kolkata-700064\n1/§.§öø. ïÒîÅîîÆî Æî¬îÏ\n\n",ifont);
			 p24.add(chunk24);
			 document.add(p24);
			 
			 
			 Paragraph p25 =new Paragraph("", ufont);
			 p25.setAlignment(Element.ALIGN_CENTER);
			 Chunk chunk25 = new Chunk("¤ï»îï¾î ¬îùÙ Ëîú ¤îÒîîÖî Ùú»îõ Ëîîý¬î Çî½î/Requsition for GuestHouse accomodation\n\n",ifont);
			 p25.add(chunk25);
			 document.add(p25);
			 
		
			  PdfPTable table13 = new PdfPTable(16);
		 table13.setWidthPercentage(100);
		 table13.addCell(createCell("´èø.Öîë./ SI NO.", 1, 1, PdfPCell.BOX));
		 table13.addCell(createCell("ÆîîËî(//´õøËî.)/ Name(Shri./Smt./Kum)", 2, 1, PdfPCell.BOX));
		 table13.addCell(createCell("Çî¿åÆîîËî/Designation", 2, 1, PdfPCell.BOX));
		 table13.addCell(createCell("•þÙÏÆîú ´øó ¤ÒîïÅî/Duration Of Stay", 1, 1, PdfPCell.BOX));
		 table13.addCell(createCell("¥´øî¥ì/ Unit", 1, 1, PdfPCell.BOX));
		 table13.addCell(createCell("¤î¬îËîÆî ´øó »îîÏó´ø »î¾îî ÖîËîÌî/ Date And time of arrival", 3, 1, PdfPCell.BOX));
		 table13.addCell(createCell("Êîõ¬î»îîÆî ´úø Çîè´øîÏ/ Mode of payment", 2, 1, PdfPCell.BOX));
		 table13.addCell(createCell("´øàî Öîë./ Room No.", 2, 1, PdfPCell.BOX));
		 table13.addCell(createCell("¤ÊÌîõï©»îÌîî ,Ìîï¿ ´øîú¥ì/ Remarks If any", 2, 1, PdfPCell.BOX));
	 
		 document.add(table13);
		 
		 
	 
		 PdfPTable table14= new PdfPTable(16);
		 table14.setWidthPercentage(100);
			 def i=1
			
		 guestList.each {
			 
			// def cd = formatDate(format:'dd-MM-yyyy',date: it.GGA_CHECK_IN_TIME)
			// def ct = formatDate(format:'H:mm',date: it.GGA_CHECK_IN_TIME)
			 def from_dt=it.GG_FROM_DT.clearTime()
			 table14.addCell(createCell("${i}", 1, i, PdfPCell.BOX));
			 table14.addCell(createCell("${it.GG_NAME}", 2, i, PdfPCell.BOX));
			 table14.addCell(createCell("${it.GG_DESGN}", 2, i, PdfPCell.BOX));
			 
			 table14.addCell(createCell("${from_dt}  ${it.GG_TO_DT}", 1, i, PdfPCell.BOX));
			 table14.addCell(createCell("${it.GG_UNIT}", 1, i, PdfPCell.BOX));
			 table14.addCell(createCell("${it.GGA_CHECK_IN_TIME}", 3, i, PdfPCell.BOX));
			 table14.addCell(createCell("${it.GG_PAY_METHOD}", 2, i, PdfPCell.BOX));
			 table14.addCell(createCell("${it.GGA_ROOM_NO}", 2, i, PdfPCell.BOX));
			 table14.addCell(createCell("",2 ,i, PdfPCell.BOX));
			 i=i+1
			 
		 }
	 
		 document.add(table14);
		 
		 Paragraph p21 =new Paragraph("", ufont);
		 p21.setAlignment(Element.ALIGN_RIGHT);
		 Chunk chunk21 = new Chunk("\n\n(§. ´úø. Çîî½îî/A.K. Pattra)\nÖîÙîÌî´ø ´øîñËî´ø ¤ïÅî´øîÏó/Assistant Personnel Officer\n",ifont);
		 p21.add(chunk21);
		 document.add(p21);
		 
		 Paragraph p20 =new Paragraph("", ufont);
		 p20.setAlignment(Element.ALIGN_LEFT);
		 Chunk chunk20 = new Chunk("\n\n»îîÏóªî/Date\n\n 1.¦Çî ËîõªÌî ÖîõÏàîî ¤ïÅî´øîÏó ,Òîó¥ìÖîóÖîó ,´øîúÑî´øî»îî /Dy. Chief security Officer ,VECC,Kolkata\n2.ÆÌî÷ ¬îú¶þ ÖîõÏàîî ¤ÆîõÊîî¬î,Òîó¥ìÖîóÖîó,´øîúÑî´øî»îî /New Gate Security Section,VECC,Kolkata.\n3.´úøÌîÏ¶úþ´øÏ ¤ï»îï¾î ¬îùÙ ,Òîó¥ìÖîóÖîó/caretaker guest House,VECC",ifont);
		 p20.add(chunk20);
		 document.add(p20);
		 
		 
		 
		 
		 
		 
		 
		 document.close()
		 println("Document Closed")
		 
		 
		 
		 OutputStream os = response.getOutputStream();
		 
		 PdfReader reader = new PdfReader( baos.toByteArray() )
		 PdfStamper stamp = new PdfStamper( reader, os)
		 
		 // properties
		 //PdfContentByte over;
		 Rectangle pagesize;
		 float x, y;
	 
		 try{
		   ( 1..reader.numberOfPages ).each{ int page ->
			   PdfContentByte under = stamp.getUnderContent(page);
			   
			   Font f = new Font(FontFamily.HELVETICA, 60);
			  /* Phrase p4 = new Phrase("This watermark is added UNDER the existing content", f);
			   ColumnText.showTextAligned(under, Element.ALIGN_CENTER, p4, 297, 550, 0);
			   PdfContentByte over = stamp.getOverContent(page);
			   p4 = new Phrase("This watermark is added ON TOP OF the existing content", f);
			   ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 500, 0);*/
			   
			   pagesize = reader.getPageSizeWithRotation(page);
			   x = (pagesize.getLeft() + pagesize.getRight()) / 2;
			   y = (pagesize.getTop() + pagesize.getBottom()) / 2;
			   
			 
				PdfContentByte over = stamp.getOverContent(page);
			   over.saveState();
			   PdfGState gs1 = new PdfGState();
			   gs1.setFillOpacity(0.5f);
			   over.setGState(gs1);
			   //ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 450, 0);
			   ColumnText.showTextAligned(over, Element.ALIGN_CENTER, ph, x, y, 45);
			   over.restoreState();
		 
		   }
		 }finally{
	 
		   stamp.close()
		   
		   reader.close();
		  
		 }
	 

	 
}
	  
  
  
  
  
  
  def checkIn(){
	  
	  def checkDate = new Date()
	  def g= Guest.get(params.gid)
	  g.GG_STATUS="checked in"
	  g.save(flush:true,failOnError:true)
	  
	  
	  def ga = GuestArchive.createCriteria()
	  def gaList = ga.list{
		  
		  eq("GGA_GID",params.gid as int)
		  
	  }
	  
	  def x = gaList.id.pop() as long
	  
	  def ga2 = GuestArchive.get(x)
	  ga2.GGA_STATUS = "checked in"
	  ga2.GGA_CHECK_IN_TIME = checkDate
	  ga2.save(flush:true,failOnError:true)
	  
	  todaysGuest()
	  
  }
  
  
  def guestCheckOut(){
	  
	  def checkOut = new Date()
	  def g= Guest.get(params.gid)
	  g.GG_STATUS="checked out"
	  g.save(flush:true,failOnError:true)
	  
	  def ga = GuestArchive.createCriteria()
	  def gaList = ga.list{
		  
		  eq("GGA_GID",params.gid as int)
		  
	  }
	  
	  def x = gaList.id.pop() as long
	  
	  def ga2 = GuestArchive.get(x)
	  ga2.GGA_STATUS = "checked out"
	  ga2.GGA_CHECK_OUT_TIME = checkOut
	  ga2.save(flush:true,failOnError:true)
	  
	  
	  currentGuest()
	  
  }
  
  
  
  
  
  def bill(){
		
		def sql=new Sql(dataSource)
		def guestBill =sql.rows("select GG_ID,GG_PAY_METHOD,GG_NAME,GG_NAME,GG_ID_CARD_NO,GG_STATUS,GB_ID,GB_GID,GB_DATE,GB_AMOUNT,GB_DESC,GB_BILL_STATUS,GG_PAY_METHOD,GG_PAYED_BY from VECUSR.GH_GUEST LEFT OUTER JOIN VECUSR.GH_BILL ON GH_GUEST.GG_ID = GH_BILL.GB_GID")
		
		render(view:"guestBill.gsp",model:[guestBill:guestBill])
	}
  
  def editBill(){
	  
	/* def b=Bill.createCriteria()
	  def bList=b.list{
		  
		  eq("GB_GID",params.gid as int )
		  eq("id",params.bid as long)
		  
	  }*/
	 /* def a=params.amount,a:a]*/
	  def sql=new Sql(dataSource)
	  def bList =sql.rows("select GG_ID,GG_PAY_METHOD,GG_NAME,GG_NAME,GG_ID_CARD_NO,GG_STATUS,GB_ID,GB_GID,GB_DATE,GB_AMOUNT,GB_DESC,GB_BILL_STATUS,GG_PAY_METHOD,GG_PAYED_BY from VECUSR.GH_GUEST LEFT OUTER JOIN VECUSR.GH_BILL ON GH_GUEST.GG_ID = GH_BILL.GB_GID where GG_ID=:gid",[gid:params.gid])
	  
	  render(view:"editBill.gsp",model:[bList:bList])
	  
	  
  }
  def payBill(){
	  
		  def g = Guest.get(params.GG_ID as long)
		  g.GG_STATUS="bill paid"
		  g.GG_PAY_METHOD=params.GG_PAY_METHOD
	  	  g.save(flush:true,failOnError:true)
		  
	      def b=Bill.get(params.GB_ID)
		  b.GB_BILL_STATUS="bill paid"
		  b.save(flush:true,failOnError:true)
	      
		  def ga = GuestArchive.createCriteria()
		  def gaList = ga.list{
			  
			  eq("GGA_GID",params.GG_ID as int)
			  
		  }
		  
		  def x = gaList.id.pop() as long
		  
		  def ga2 = GuestArchive.get(x)
		  ga2.GGA_STATUS = "bill paid"
		  ga2.GGA_TOTAL_BILL = params.GB_AMOUNT as int
		  ga2.save(flush:true,failOnError:true)
		  
		  bill();
		  
		  
	  }
  
  
  def newBill(){
	  
	  def ex = GuestExpenditure.createCriteria()
	  def expList=ex.list{
		  
			  eq("GGE_GID",params.gid as int)
			 
		  
	  }
	  
	  def x = 0
	  def foodCost = 0
	  if(expList){
		  for (item in expList){
			  
			  x = item.GGE_AMOUNT as int
			  foodCost = foodCost + x
			  
		  }
	  }
	  def desc ="lodging"
	  
	  if(expList){
		  
		  desc = desc +", "+ "fooding"
	  }
	  
	  
	  def g = Guest.createCriteria()
	  def guest=g.list{
		  
		  eq("id",params.gid as long)
	  }
	  
	  
	  def nod=guest.GG_NO_OF_DAYS.pop() as int
	  def rf=guest.GG_ROOM_FACILITY.pop()
	  def gc=guest.GG_TID.pop() as long
	  def gb_or_gr=guest.GG_BED_OR_ROOM.pop()
	  def no_b_or_r=guest.GG_NO_OF_BED_OR_ROOM.pop() as int
	  
	  def t= Tariff.createCriteria()  
	  def tList=t.list{
		  
		  eq("id",gc)
		  
	  }
	  
	  def tariff
	  
	  if(rf=="AC")
	  {
		 tariff=tList.GT_AC_CHARGE.pop() as int
	  }
	  else
	  {
		  tariff=tList.GT_NAC_CHARGE.pop() as int
	  }
	  
	  def lodgingCost
	  
	  if(gb_or_gr=="bed"){
		  
		  lodgingCost=no_b_or_r * tariff
	  }
	  else
	  {
		  lodgingCost=(2 * (no_b_or_r * tariff))
	  }
	  
	  lodgingCost=lodgingCost * nod
	  
	  
	  
	  def totalBill = foodCost + lodgingCost
	  def b = Bill.get(params.bid)
	
	  b.id=params.bid as int
	  b.GB_GID=params.gid as int
	  if(params.GB_DATE)
	  b.GB_DATE=Date.parse('yyyy-MM-dd', (params.GB_DATE))
	  b.GB_AMOUNT=totalBill as int
	  b.GB_DESC=desc
	  b.GB_BILL_STATUS="bill generated"
	  b.save(flush:true,failOnError:true)
	  
	  bill();
	  
	  
  }
  
  
  def printBill(){
	  
	  
	  def g = Guest.createCriteria()
	  def guest=g.list{
		  
		  eq("id",params.gid as long)
	  }
	  
	  
	  def nod=guest.GG_NO_OF_DAYS.pop() as int
	  def rf=guest.GG_ROOM_FACILITY.pop()
	  def gc=guest.GG_TID.pop() as long
	  def gb_or_gr=guest.GG_BED_OR_ROOM.pop()
	  def no_b_or_r=guest.GG_NO_OF_BED_OR_ROOM.pop() as int
	  
	  def t= Tariff.createCriteria()
	  def tList=t.list{
		  
		  eq("id",gc)
		  
	  }
	  
	  def tariff
	  
	  if(rf=="AC")
	  {
		 tariff=tList.GT_AC_CHARGE.pop() as int
	  }
	  else
	  {
		  tariff=tList.GT_NAC_CHARGE.pop() as int
	  }
	  
	  def lodgingCost
	  
	  if(gb_or_gr=="bed"){
		  
		  lodgingCost=no_b_or_r * tariff
	  }
	  else
	  {
		  lodgingCost=(2 * (no_b_or_r * tariff))
	  }
	  
	  def lpd = lodgingCost
	  
	  lodgingCost=lodgingCost * nod
	  
	  def ex = GuestExpenditure.createCriteria()
	  def expList=ex.list{
		  
			  eq("GGE_GID",params.gid as int)
			 
		  
	  }
	  
	  def x = 0
	  def foodCost = 0
	  if(expList){
		  for (item in expList){
			  
			  x = item.GGE_AMOUNT as int
			  foodCost = foodCost + x
			  
		  }
	  }
	  
	  def totalBill = foodCost + lodgingCost
	  
	  render(view:"printBill.gsp",model:[guest:guest,tariff:tariff,lpd:lpd,lodgingCost:lodgingCost,expList:expList,foodCost:foodCost,totalBill:totalBill])
  }
  
  
  def billDetails(){
	  
	  
	  def g = Guest.createCriteria()
	  def guest=g.list{
		  
		  eq("id",params.gid as long)
	  }
	  
	  
	  def nod=guest.GG_NO_OF_DAYS.pop() as int
	  def rf=guest.GG_ROOM_FACILITY.pop()
	  def gc=guest.GG_TID.pop() as long
	  def gb_or_gr=guest.GG_BED_OR_ROOM.pop()
	  def no_b_or_r=guest.GG_NO_OF_BED_OR_ROOM.pop() as int
	  
	  def t= Tariff.createCriteria()
	  def tList=t.list{
		  
		  eq("id",gc)
		  
	  }
	  
	  def tariff
	  
	  if(rf=="AC")
	  {
		 tariff=tList.GT_AC_CHARGE.pop() as int
	  }
	  else
	  {
		  tariff=tList.GT_NAC_CHARGE.pop() as int
	  }
	  
	  def lodgingCost
	  
	  if(gb_or_gr=="bed"){
		  
		  lodgingCost=no_b_or_r * tariff
	  }
	  else
	  {
		  lodgingCost=(2 * (no_b_or_r * tariff))
	  }
	  
	  def lpd = lodgingCost
	  
	  lodgingCost=lodgingCost * nod
	  
	  def ex = GuestExpenditure.createCriteria()
	  def expList=ex.list{
		  
			  eq("GGE_GID",params.gid as int)
			 
		  
	  }
	  
	  def x = 0
	  def foodCost = 0
	  if(expList){
		  for (item in expList){
			  
			  x = item.GGE_AMOUNT as int
			  foodCost = foodCost + x
			  
		  }
	  }
	  
	  def totalBill = foodCost + lodgingCost
	  
	  render(view:"billDetails.gsp",model:[guest:guest,tariff:tariff,lpd:lpd,lodgingCost:lodgingCost,expList:expList,foodCost:foodCost,totalBill:totalBill])
  }

  def guestDetails(){
	  
	  
	  
	  def sql=new Sql(dataSource)
	  def g=sql.rows("select GG_ID,GG_NAME,GG_DESGN,GG_UNIT,GG_FROM_DT,GG_TO_DT,GG_NO_OF_MEM,GG_STATUS,GGA_ROOM_NO,GGA_GID from VECUSR.GH_GUEST_ARCHIVE INNER JOIN VECUSR.GH_GUEST ON GH_GUEST_ARCHIVE.GGA_GID = GH_GUEST.GG_ID where GG_STATUS=:gs1 OR GG_STATUS=:gs2 OR GG_STATUS=:gs4 OR GG_STATUS=:gs5",[gs1:"booked",gs2:"checked in",gs4:"checked out",gs5:"cep generated"])
	  
	  render(view:"guestDetailsSec.gsp",model:[g:g])
  }
  
  def genCep(){
	 
	  println"======="+params.guid
	  def g = Guest.get(params.guid)
	  if(g.GG_STATUS =="booked")
	  g.GG_STATUS = "cep generated"
	  
	  g.save(flush:true,failOnError:true)
	  guestDetails()
  }
  
  def printCep(){
	  
	  def guestId = params.gid as long
	  def sql=new Sql(dataSource)
	  def g=sql.rows("select GG_ID,GG_NAME,GG_DESGN,GG_UNIT,GG_FROM_DT,GG_TO_DT,GG_NO_OF_MEM,GG_STATUS,GGA_ROOM_NO,GGA_GID from VECUSR.GH_GUEST_ARCHIVE INNER JOIN VECUSR.GH_GUEST ON GH_GUEST_ARCHIVE.GGA_GID = GH_GUEST.GG_ID where GG_STATUS=:gs1 OR GG_STATUS=:gs2 OR GG_STATUS=:gs4 OR GG_STATUS=:gs5",[gs1:"booked",gs2:"checked in",gs4:"checked out",gs5:"cep generated"])
	  
	  render(view:"printCep.gsp",model:[g:g,guestId:guestId])
	 
  }
  
   def printCepPdf(){
	  
	  
	  //println "params.appId"+params.appId
	  //def appId =  (new String ((params.appId).decodeBase64())) as long
	  
	  //def PERID =  (new String ((params.PERID).decodeBase64())) as int
	  //println "appId"+appId
	  
	  
  
	    // step 1
	  float left = 30;
	  float right = 30;
	  float top = 60;
	  float bottom = 0;
		  def document = new Document(PageSize.A4, left, right, top, bottom)
		  //println("Document Created")
		  
		  // step 2
		  //PdfWriter.getInstance(document, new FileOutputStream("TaCash111.pdf"))
		  ByteArrayOutputStream baos = new ByteArrayOutputStream();
		  PdfWriter.getInstance(document, baos);
		  //println("PdfWriter Created")
		  

		  
		  
		  // step 3
		  document.open()
		  BaseFont ihnd = BaseFont.createFont("web-app/fonts/DVBIYG3NT.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			  Font ifont=new Font(ihnd,14,Font.NORMAL,new BaseColor(0,0,0));
			  Font ifontb=new Font(ihnd,14,Font.BOLD,new BaseColor(0,0,0));
			  
		  BaseFont uhnd = BaseFont.createFont("web-app/fonts/ARIALUNI.TTF",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			  // for green Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(50,205,50));
			  Font ufont=new Font(uhnd,12,Font.NORMAL,new BaseColor(0,0,0));
		  BaseFont tnr = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			  Font tnrf=new Font(tnr,12,Font.NORMAL,new BaseColor(50,0,50));
			  
			  BaseFont tnrb = BaseFont.createFont("web-app/fonts/Times_New_Roman_Normal.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			  Font tnrfb=new Font(tnrb,12,Font.BOLD,new BaseColor(50,0,50));
			  
		  BaseFont fs = BaseFont.createFont("web-app/fonts/FreeSans.ttf",BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			  Font fsf=new Font(fs,12,Font.NORMAL,new BaseColor(50,205,50));
	  
			  
			  
			  
			  Paragraph p15 =new Paragraph("", ifontb);
			  p15.setAlignment(Element.ALIGN_CENTER);
			  Chunk chunk13 = new Chunk("ÊîîÏ»î ÖîÏ´øîÏ/Goverment Of India\n ÇîÏËîîÆîõ ¦²îîì ïÒîÊîî¬î/Department of Atomic Energy\nÇîïÏÒî»îóì ¦²îîì Öîî¥©Ñîîú¶þîýÆî ´úøÆ¿èþ/Variable Cyclotron centre\n",ifont);
			  p15.add(chunk13);
			  document.add(p15);
			  
			  
			  Paragraph p24 =new Paragraph("", ifontb);
			  p24.setAlignment(Element.ALIGN_RIGHT);
			  Chunk chunk24 = new Chunk("1/A.F. Bidhan Nagar , Kolkata-700064\n1/1/§.§öø. ïÒîÅîîÆî Æî¬îÏ ´øîúÑî´øî»îî-700064\n\n",ifont);
			  p24.add(chunk24);
			  document.add(p24);
			  
			
			
			Paragraph p6 =new Paragraph("", ufont)
			p6.setAlignment(Element.ALIGN_CENTER);
			Chunk chunk6 = new Chunk("Guest House Gate Pass",ifontb);
			chunk6.setUnderline(1.5f, -5.0f);
			p6.add(chunk6)
			Chunk chunk61 = new Chunk("\n\n",ifontb);
			p6.add(chunk61)
			document.add(p6);
		  
		  
			def guestId = params.gid as long
			def guest = Guest.createCriteria()
			def g = guest.list{
				
				eq("id",guestId)
			}
			
			
			def rt = RoomTransaction.createCriteria()
			def rtList = rt.list{
				
				eq("GRT_GID",guestId as int)
			}
			
			def gid = g.id.pop() as long
			def gname = g.GG_NAME.pop()
			def gdesg = g.GG_DESGN.pop()
			def gunit = g.GG_UNIT.pop()
			def gnom = g.GG_NO_OF_MEM.pop() as int
			def groom = rtList.GRT_ROOM_NO.pop() as int
			def gardate = g.GG_FROM_DT.pop()
			def gdepdate = g.GG_TO_DT.pop()
			
			
			
			
			Paragraph p7 =new Paragraph("", ufont)
			p7.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk7 = new Chunk("1. Sl No. :  ${gid}\n\n",ifontb);
			p7.add(chunk7)
			document.add(p7);
		  
			
			Paragraph p8 =new Paragraph("", ufont)
			p8.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk8 = new Chunk("2. Name of the Guest : ${gname}\n\n",ifontb);
			p8.add(chunk8)
			document.add(p8);
		  
			
			Paragraph p9 =new Paragraph("", ufont)
			p9.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk9 = new Chunk("3. Designation :  ${gdesg}\n\n",ifontb);
			p9.add(chunk9)
			document.add(p9);
		  
			
			Paragraph p10 =new Paragraph("", ufont)
			p10.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk10 = new Chunk("4. Unit Name :  ${gunit}\n\n",ifontb);
			p10.add(chunk10)
			document.add(p10);
		  
			
			Paragraph p11 =new Paragraph("", ufont)
			p11.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk11 = new Chunk("5. No. of members : ${gnom}\n\n",ifontb);
			p11.add(chunk11)
			document.add(p11);
		  
			
			Paragraph p12 =new Paragraph("", ufont)
			p12.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk12 = new Chunk("6. Room No. :  ${groom}\n\n",ifontb);
			p12.add(chunk12)
			document.add(p12);
		  
			
			Paragraph p16 =new Paragraph("", ufont)
			p16.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk16 = new Chunk("7. Arrival date :  ${gardate}\n\n",ifontb);
			p16.add(chunk16)
			document.add(p16);
		  
			
			Paragraph p14 =new Paragraph("", ufont)
			p14.setAlignment(Element.ALIGN_LEFT);
			Chunk chunk14 = new Chunk("8. Departure date :  ${gdepdate}\n\n",ifontb);
			p14.add(chunk14)
			document.add(p14);
		  
			Paragraph p17 =new Paragraph("", ufont)
			p17.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk17 = new Chunk("Signature of S/G",ifontb);
			p17.add(chunk17)
			document.add(p17);
		  
		  
		  
		  
		  
		  
		  
		  
		  document.close()
		  println("Document Closed")
		  
		  
		  
		  OutputStream os = response.getOutputStream();
		  
		  PdfReader reader = new PdfReader( baos.toByteArray() )
		  PdfStamper stamp = new PdfStamper( reader, os)
		  
		  // properties
		  //PdfContentByte over;
		  Rectangle pagesize;
		  float x, y;
	  
		  try{
			( 1..reader.numberOfPages ).each{ int page ->
				PdfContentByte under = stamp.getUnderContent(page);
				
				Font f = new Font(FontFamily.HELVETICA, 60);
			   /* Phrase p4 = new Phrase("This watermark is added UNDER the existing content", f);
				ColumnText.showTextAligned(under, Element.ALIGN_CENTER, p4, 297, 550, 0);
				PdfContentByte over = stamp.getOverContent(page);
				p4 = new Phrase("This watermark is added ON TOP OF the existing content", f);
				ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 500, 0);*/
				
				pagesize = reader.getPageSizeWithRotation(page);
				x = (pagesize.getLeft() + pagesize.getRight()) / 2;
				y = (pagesize.getTop() + pagesize.getBottom()) / 2;
				
				//Phrase ph = new Phrase("TEST" as String, f);
				 PdfContentByte over = stamp.getOverContent(page);
				over.saveState();
				PdfGState gs1 = new PdfGState();
				gs1.setFillOpacity(0.5f);
				over.setGState(gs1);
				//ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p4, 297, 450, 0);
				ColumnText.showTextAligned(over, Element.ALIGN_CENTER, ph, x, y, 45);
				over.restoreState();
		  
			}
		  }finally{
	  
			stamp.close()
			
			reader.close();
		   
		  }
	  
	  
  }
   
   
  def admRequisition(){
	  
	  def sql=new Sql(dataSource)
	  def reqList=sql.rows("select GG_ID,GG_GENDER,GG_REQ_DT,GG_ID,GG_REQ_ID,GG_NAME,GG_UNIT,GG_FROM_DT,GG_TO_DT,GG_STATUS,GR_NAME,GR_ID from VECUSR.GH_REQUISITION INNER JOIN VECUSR.GH_GUEST ON GH_REQUISITION.GR_ID = GH_GUEST.GG_REQ_ID ORDER BY GG_REQ_DT DESC")
		render(view:"admBooking.gsp",model:[reqList:reqList])  
	  
  }
  def admReqDetails(){
	  
	  def r = Requisition.createCriteria()
	  def reqList=r.list {
		  
		  eq("id",params.rid as long)
		  
	  }
	  
	  def g = Guest.createCriteria()
	  def gList=g.list{
		  
		  eq("id",params.guid as long)
		  
	  }
	  
	  def f = Family.createCriteria()
	  def fList= f.list{
		  
		  eq("GF_GID",params.guid as int)
	  }
	  
	  render(view:"admReqDetails.gsp", model:[reqList:reqList, gList:gList, fList:fList])
	  
  }
  
 
  
  def allotRoom(){
 
	  def gid=params.gid as long
	  def g = Guest.createCriteria()
	  def gList=g.list{
		  
		  eq("id",gid)
		  
	  }
	  def fromdt=params.fdt
	  def todt=params.tdt 
	  
	  def b_or_r=gList.GG_BED_OR_ROOM.pop()
	  def no_b_or_r=gList.GG_NO_OF_BED_OR_ROOM.pop() as int
	  
	
	  
	  def r=Room.createCriteria()
	  def rList=r.list{
		  eq("GR_TYPE","HO")
		  projections{
			  property('id')
			  
			  
		  }
	  }
  
	  def r1=Room.createCriteria()
	  def rListHoRsv=r1.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","HO")
		  }
		  projections{
			  property('id')
			  
		  }
	  }
	  
	  
	  def r4=Room.createCriteria()
	  def rListHoRsvAll=r4.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","HO")
		  }
		  
	  }
	  
	  
	  for (item in rListHoRsvAll){
		  def x = item.id  as int
		  
		  if(item.GR_BED_NO == "both")
		  
		  {
			  rList = rList.minus([x-1,x-2])
		  }
		  
		  else if (item.GR_BED_NO == "A"){
			  
			  
			  rList = rList.minus([x+2])
		  }
		  
		  else{
			  rList = rList.minus([x+1])
		  }
	  }
	  
	  
	  rList = rList.minus(rListHoRsv)
	  
	  
	  def rt=RoomTransaction.createCriteria()
	  def rtList=rt.list{
		  or{
			  
			  sqlRestriction("GRT_FROM_DT BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("GRT_TO_DT BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
		  projections{
			  property('GRT_GR_ID')
			  }
		
	  }
	  
	  def rtHO=RoomTransaction.createCriteria()
	  def rtListHO=rtHO.list{
		  and{
			  
			  eq("GRT_GH_TYPE","HO")
		  
		  or{ 
			  sqlRestriction("GRT_FROM_DT BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("GRT_TO_DT BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
		  }
	  }
	  
	 for (item in rtListHO){
		  def x = item.GRT_GR_ID as int
		  
		  if(item.GRT_BED_NO == "both")
		  
		  { 
			  rList = rList.minus([x-1,x-2])
		  }
		  
		  else if (item.GRT_BED_NO == "A"){
			  
			  
			  rList = rList.minus([x+2])
		  }
		  
		  else{
			  rList = rList.minus([x+1])
		  }
	  }
	  
	 
	  def roomAvailList1 = rList.minus(rtList);
	    
	  def room = Room.createCriteria()
	  def roomListHO = room.list{
		  
		  'in'("id",roomAvailList1)
		  
	   }
	  
	  
	  def r2=Room.createCriteria()
	  def rList2=r2.list{
		  eq("GR_TYPE","SJ")
		  projections{
			  property('id')
			  
			  
		  }
	  }
	  
	  
	  def r3=Room.createCriteria()
	  def rListSjRsv=r3.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","SJ")
		  }
		  projections{
			  property('id')
			  
		  }
	  }
	  
	  def r5=Room.createCriteria()
	  def rListSjRsvAll=r5.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","SJ")
		  }
		  
	  }
	  
	  
	  for (item in rListSjRsvAll){
		  def x = item.id as int
		  
		  if(item.GR_BED_NO == "both")
		  
		  {
			  rList2 = rList2.minus([x-1,x-2])
		  }
		  
		  else if (item.GR_BED_NO == "A"){
			  
			  
			  rList2 = rList2.minus([x+2])
		  }
		  
		  else{
			  rList2 = rList2.minus([x+1])
		  }
	  }
	  rList2 = rList2.minus(rListSjRsv)
	  
	  
	  
	  def rtSJ=RoomTransaction.createCriteria()
	  def rtListSJ=rtSJ.list{
		  
		  and{
			  
			  eq("GRT_GH_TYPE","SJ")
		  or{
			  sqlRestriction("GRT_FROM_DT BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("GRT_TO_DT BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
		  }
	  }
	  
	  for (item in rtListSJ){
		  def x = item.GRT_GR_ID as int
		  
		  if(item.GRT_BED_NO == "both")
		  
		  {
			  rList2 = rList2.minus([x-1,x-2])
		  }
		  
		  else if (item.GRT_BED_NO == "A"){
			  
			  
			  rList2 = rList2.minus([x+2])
		  }
		  
		  else{
			  rList2 = rList2.minus([x+1])
		  }
	  }
	  
	  def roomAvailList2 = rList2.minus(rtList);
	  
	def room2 = Room.createCriteria()
	def roomListSJ = room2.list{
		
		'in'("id",roomAvailList2)
		
	 }
	  
	def flag = 0
	 
	  render(view:"allotRoom.gsp",model:[gList:gList,roomListHO:roomListHO,roomListSJ:roomListSJ,b_or_r:b_or_r,no_b_or_r:no_b_or_r,flag:flag])
  }
 
  
 
  
  
  
  def roomBook(){
	  def guestId=params.gid as long
	  def roomId=params.rid as long
	  def rno=params.rno as int
	  def bno=params.bno
	  
	  
	  
	 
	  
	  def guest=Guest.createCriteria()
	  def gList=guest.list{
		  
		  eq("id",guestId)
	  }
	  
	  def b_or_r=gList.GG_BED_OR_ROOM.pop()
	  def no_b_or_r=gList.GG_NO_OF_BED_OR_ROOM.pop() as int
	  
	  def sql=new Sql(dataSource)
	  def reqGue=sql.rows("select GR_ID,GG_ID,GG_REQ_ID,GR_NAME from VECUSR.GH_REQUISITION INNER JOIN VECUSR.GH_GUEST ON GH_REQUISITION.GR_ID = GH_GUEST.GG_REQ_ID where GG_ID=:gid",[gid:guestId])
	  	  
	  
	  def g= Guest.get(guestId)
	  g.GG_STATUS="booked"
	  g.save(flush:true,failOnError:true)
	  
	  
	  
	  def rtidl=sql.rows("select nvl(max(GRT_ID),0 )+1 rtid1 from GH_ROOM_TRANSACTION")
	  def rtid= rtidl.pop().rtid1
	  
	  def rt=new RoomTransaction()
	   
	  rt.id=rtid as int
	  rt.GRT_GID=guestId as int
	  rt.GRT_GR_ID=roomId as int
	  rt.GRT_ROOM_NO=rno as int
	  rt.GRT_STATUS="booked"
	  rt.GRT_FROM_DT=gList.GG_FROM_DT.pop()
	  rt.GRT_TO_DT=gList.GG_TO_DT.pop()
	  rt.GRT_BED_NO=bno
	  rt.GRT_GH_TYPE=gList.GG_GH_TYPE.pop()
	  rt.save(flush:true,failOnError:true)
	  
	 
	  def gaidl=sql.rows("select nvl(max(GGA_ID),0 )+1 gaid1 from GH_GUEST_ARCHIVE")
	  def gaid= gaidl.pop().gaid1
	  
	  def ga=new GuestArchive()
	  ga.id=gaid as long
	  ga.GGA_GID=guestId as int
	  ga.GGA_REQ_ID=gList.GG_REQ_ID.pop()
	  ga.GGA_ROOM_ID=roomId as int
	  
	  ga.GGA_REQUISITION_NAME=reqGue.GR_NAME.pop()
	  ga.GGA_GUEST_NAME=gList.GG_NAME.pop()
	  ga.GGA_ROOM_NO=rno as int
	  ga.GGA_BED_NO=bno
	  ga.GGA_STATUS="booked"
	 /* def model = [:]
	  model['ga'] = ga
	 
	  if (ga.save(flush: true)) {
		  // set/lookup the error message
		  model['Message'] = message(code: 'Room has been booked:')
		  // render the view
		  render(model: model)
	  
		  return
	  }*/
	  ga.save(flush:true,failOnError:true)
	  
	  
	  if (no_b_or_r == 1)
	  {
		  admRequisition()
	  }
	   
	  
	  else{
	 int n = 1;
	  int flag = params.flag as int
	  
	  	
	 for(n = 1; n <= no_b_or_r - 1 ; n++){
		  
		 
		  		flag = flag + 1
				 def gid=guestId as long
				 def g1 = Guest.createCriteria()
				 def guList=g1.list{
					 
					 eq("id",gid)
					 
				 }
				 
				 def fromdt=formatDate(format:'dd-MM-yyyy',date: guList.GG_FROM_DT.pop())
				 def todt=formatDate(format:'dd-MM-yyyy',date: guList.GG_TO_DT.pop())
				 
				 
				 def r=Room.createCriteria()
				 def rList=r.list{
					 eq("GR_TYPE","HO")
					 projections{
						 property('id')
						 
						 
					 }
				 }
				 
				 
				 def r1=Room.createCriteria()
				 def rListHoRsv=r1.list{
					 
					 and{
						 
						 or{
							 sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
							 sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
						 
						 eq("GR_TYPE","HO")
					 }
					 projections{
						 property('id')
						 
					 }
				 }
				 
				 
				 def r4=Room.createCriteria()
				 def rListHoRsvAll=r4.list{
					 
					 and{
						 
						 or{
							 sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
							 sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
						 
						 eq("GR_TYPE","HO")
					 }
					 
				 }
				 
				 
				 for (item in rListHoRsvAll){
					 def x = item.id  as int
					 
					 if(item.GR_BED_NO == "both")
					 
					 {
						 rList = rList.minus([x-1,x-2])
					 }
					 
					 else if (item.GR_BED_NO == "A"){
						 
						 
						 rList = rList.minus([x+2])
					 }
					 
					 else{
						 rList = rList.minus([x+1])
					 }
				 }
				 
				 
				 rList = rList.minus(rListHoRsv)
				 
				 
				 def rt1=RoomTransaction.createCriteria()
				 def rtList1=rt1.list{
					 or{
						 
						 sqlRestriction("GRT_FROM_DT BETWEEN '"+ fromdt +"' AND '"+todt+"'")
						 sqlRestriction("GRT_TO_DT BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
					 projections{
						 property('GRT_GR_ID')
						 }
				   
				 }
				 
				def rtHO=RoomTransaction.createCriteria()
				 def rtListHO=rtHO.list{
					 
					 and{
						 	eq("GRT_GH_TYPE","HO")
					 
					 or{
						 sqlRestriction("GRT_FROM_DT BETWEEN '"+ fromdt +"' AND '"+todt+"'")
						 sqlRestriction("GRT_TO_DT BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
					 }
				 }
				 
				for (item in rtListHO){
					 def x = item.GRT_GR_ID as int
					 
					 if(item.GRT_BED_NO == "both")
					 
					 {
						 rList = rList.minus([x-1,x-2])
					 }
					 
					 else if (item.GRT_BED_NO == "A"){
						 
						 
						 rList = rList.minus([x+2])
					 }
					 
					 else{
						 rList = rList.minus([x+1])
					 }
				 }
				 
				
				 def roomAvailList1 = rList.minus(rtList1);
				   
				 def room = Room.createCriteria()
				 def roomListHO = room.list{
					 
					 'in'("id",roomAvailList1)
					 
				  }
				 
				 
				 def r2=Room.createCriteria()
				 def rList2=r2.list{
					 eq("GR_TYPE","SJ")
					 projections{
						 property('id')
						 
						 
					 }
				 }
				 
				 def r3=Room.createCriteria()
				 def rListSjRsv=r3.list{
					 
					 and{
						 
						 or{
							 sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
							 sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
						 
						 eq("GR_TYPE","SJ")
					 }
					 projections{
						 property('id')
						 
					 }
				 }
				 
				 def r5=Room.createCriteria()
				 def rListSjRsvAll=r5.list{
					 
					 and{
						 
						 or{
							 sqlRestriction("GR_RESR_FROM BETWEEN '"+ fromdt +"' AND '"+todt+"'")
							 sqlRestriction("GR_RESR_TO BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
						 
						 eq("GR_TYPE","SJ")
					 }
					 
				 }
				 
				 
				 for (item in rListSjRsvAll){
					 def x = item.id as int
					 
					 if(item.GR_BED_NO == "both")
					 
					 {
						 rList2 = rList2.minus([x-1,x-2])
					 }
					 
					 else if (item.GR_BED_NO == "A"){
						 
						 
						 rList2 = rList2.minus([x+2])
					 }
					 
					 else{
						 rList2 = rList2.minus([x+1])
					 }
				 }
				 rList2 = rList2.minus(rListSjRsv)
				 
				 
				 
				 def rtSJ=RoomTransaction.createCriteria()
				 def rtListSJ=rtSJ.list{
					 
					 and{
							 eq("GRT_GH_TYPE","SJ")
					 
					 or{
						 sqlRestriction("GRT_FROM_DT BETWEEN '"+ fromdt +"' AND '"+todt+"'")
						 sqlRestriction("GRT_TO_DT BETWEEN'"+ fromdt +"' AND '"+todt+"'")
						 }
					 }
				 }
				 
				 for (item in rtListSJ){
					 def x = item.GRT_GR_ID as int
					 
					 if(item.GRT_BED_NO == "both")
					 
					 {
						 rList2 = rList2.minus([x-1,x-2])
					 }
					 
					 else if (item.GRT_BED_NO == "A"){
						 
						 
						 rList2 = rList2.minus([x+2])
					 }
					 
					 else{
						 rList2 = rList2.minus([x+1])
					 }
				 }
				 
				 def roomAvailList2 = rList2.minus(rtList1);
				 
			   def room2 = Room.createCriteria()
			   def roomListSJ = room2.list{
				   
				   'in'("id",roomAvailList2)
				   
				}
			 
				
				 render(view:"allotRoom.gsp",model:[gList:gList,roomListHO:roomListHO,roomListSJ:roomListSJ,b_or_r:b_or_r,no_b_or_r:no_b_or_r,flag:flag])
				 
				 
				  println"helo==================="
	  }
	  }
	 
  }
  
  
  
  def guestArch(){
	  
	  def ga = GuestArchive.createCriteria()
	  def gaList = ga.list{
		  
		  
	  }
	  render(view:"guestArchive.gsp",model:[gaList:gaList])
  }
  
  
  
  def cancelBookingAdm(){
	  
	  
	  def guestId = params.gid as int
	  
	  def g = Guest.get(guestId)
	  g.GG_STATUS= "booking cancelled"
	  g.save(flush:true,failOnError:true)
	  
	  def ga1= GuestArchive.createCriteria()
	  def gaList = ga1.list{
		  
		  eq("GGA_GID",guestId)
	  }
	  
	  def gaId = gaList.id.pop()
	  def ga = GuestArchive.get(gaId)
	  ga.GGA_STATUS = "booking cancelled"
	  ga.save(flush:true,failOnError:true)
	  
	  
	  def rt1 = RoomTransaction.createCriteria()
	  def rtList= rt1.list{
		  
		  eq("GRT_GID",guestId)
	  }
	  
	  
	  def rtId = rtList.id.pop()
	  def rt = RoomTransaction.get(rtId)
	  rt.delete(flush:true,failOnError:true)
	  
	  guestArch()
	  
	  
  }
  
  
  
  def roomAvail(){
	  
	  def room = Room.createCriteria()
	  def roomList= room.list{
		  
	  }
	  
	render(view:"roomAvailability.gsp",model:[roomList:roomList])  
	  
  }
  
  
  def searchRoomAvail(){
	  
	  def fromdt=params.from_dt
	  def todt=params.to_dt 
	  
	
	
	  
	  def r=Room.createCriteria()
	  def rList=r.list{
		  eq("GR_TYPE","HO")
		  projections{
			  property('id')
			  
			  
		  }
	  }
  
	  def r1=Room.createCriteria()
	  def rListHoRsv=r1.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("TO_CHAR(GR_RESR_TO ,'YYYY-MM-DD')  BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","HO")
		  }
		  projections{
			  property('id')
			  
		  }
	  }
	  
	  
	  def r4=Room.createCriteria()
	  def rListHoRsvAll=r4.list{
		  
		  and{
			  
			  or{
				 sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("TO_CHAR(GR_RESR_TO ,'YYYY-MM-DD')  BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","HO")
		  }
		  
	  }
	  
	  
	  for (item in rListHoRsvAll){
		  def x = item.id  as int
		  
		  if(item.GR_BED_NO == "both")
		  
		  {
			  rList = rList.minus([x-1,x-2])
		  }
		  
		  else if (item.GR_BED_NO == "A"){
			  
			  
			  rList = rList.minus([x+2])
		  }
		  
		  else{
			  rList = rList.minus([x+1])
		  }
	  }
	  
	  
	  rList = rList.minus(rListHoRsv)
	  
	  
	  def rt=RoomTransaction.createCriteria()
	  def rtList=rt.list{
		  or{
			  
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
		  projections{
			  property('GRT_GR_ID')
			  }
		
	  }
	  
	  def rtHO=RoomTransaction.createCriteria()
	  def rtListHO=rtHO.list{
		  and{
			  
			  eq("GRT_GH_TYPE","HO")
		  
		  or{ 
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
		  }
	  }
	  
	 for (item in rtListHO){
		  def x = item.GRT_GR_ID as int
		  
		  if(item.GRT_BED_NO == "both")
		  
		  { 
			  rList = rList.minus([x-1,x-2])
		  }
		  
		  else if (item.GRT_BED_NO == "A"){
			  
			  
			  rList = rList.minus([x+2])
		  }
		  
		  else{
			  rList = rList.minus([x+1])
		  }
	  }
	  
	 
	  def roomAvailList1 = rList.minus(rtList);
	    
	  def room = Room.createCriteria()
	  def roomListHO = room.list{
		  
		  'in'("id",roomAvailList1)
		  
	   }
	  
	  
	  def r2=Room.createCriteria()
	  def rList2=r2.list{
		  eq("GR_TYPE","SJ")
		  projections{
			  property('id')
			  
			  
		  }
	  }
	  
	  
	  def r3=Room.createCriteria()
	  def rListSjRsv=r3.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GR_RESR_TO,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","SJ")
		  }
		  projections{
			  property('id')
			  
		  }
	  }
	  
	  def r5=Room.createCriteria()
	  def rListSjRsvAll=r5.list{
		  
		  and{
			  
			  or{
				   sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				   sqlRestriction("TO_CHAR(GR_RESR_TO,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","SJ")
		  }
		  
	  }
	  
	  
	  for (item in rListSjRsvAll){
		  def x = item.id as int
		  
		  if(item.GR_BED_NO == "both")
		  
		  {
			  rList2 = rList2.minus([x-1,x-2])
		  }
		  
		  else if (item.GR_BED_NO == "A"){
			  
			  
			  rList2 = rList2.minus([x+2])
		  }
		  
		  else{
			  rList2 = rList2.minus([x+1])
		  }
	  }
	  rList2 = rList2.minus(rListSjRsv)
	  
	  
	  
	  def rtSJ=RoomTransaction.createCriteria()
	  def rtListSJ=rtSJ.list{
		  
		  and{
			  
			  eq("GRT_GH_TYPE","SJ")
		  or{
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GRT_TO_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
		  }
	  }
	  
	  for (item in rtListSJ){
		  def x = item.GRT_GR_ID as int
		  
		  if(item.GRT_BED_NO == "both")
		  
		  {
			  rList2 = rList2.minus([x-1,x-2])
		  }
		  
		  else if (item.GRT_BED_NO == "A"){
			  
			  
			  rList2 = rList2.minus([x+2])
		  }
		  
		  else{
			  rList2 = rList2.minus([x+1])
		  }
	  }
	  
	  def roomAvailList2 = rList2.minus(rtList);
	  
	  
	def room2 = Room.createCriteria()
	def roomListSJ = room2.list{
		
		'in'("id",roomAvailList2)
		
	 }
	  
   /*  fromdt=Date.parse('dd-MM-YYYY',fromdt)
	 todt=Date.parse('dd-MM-YYYY',todt)*/
	 
	 render(view:"searchRoomAvail.gsp",model:[roomListHO:roomListHO,roomListSJ:roomListSJ,fromdt:fromdt,todt:todt])

  
  }
  
  
  
  def roomAvailgh(){
	  
	  def room = Room.createCriteria()
	  def roomList= room.list{
		  
	  }
	  
	render(view:"roomAvailabilitygh.gsp",model:[roomList:roomList])
	  
  }
  
  
  def searchRoomAvailgh(){
	  
	  def fromdt=params.from_dt
	  def todt=params.to_dt
	  
	
	
	  
	  def r=Room.createCriteria()
	  def rList=r.list{
		  eq("GR_TYPE","HO")
		  projections{
			  property('id')
			  
			  
		  }
	  }
  
	  def r1=Room.createCriteria()
	  def rListHoRsv=r1.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("TO_CHAR(GR_RESR_TO ,'YYYY-MM-DD')  BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","HO")
		  }
		  projections{
			  property('id')
			  
		  }
	  }
	  
	  
	  def r4=Room.createCriteria()
	  def rListHoRsvAll=r4.list{
		  
		  and{
			  
			  or{
				 sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				  sqlRestriction("TO_CHAR(GR_RESR_TO ,'YYYY-MM-DD')  BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","HO")
		  }
		  
	  }
	  
	  
	  for (item in rListHoRsvAll){
		  def x = item.id  as int
		  
		  if(item.GR_BED_NO == "both")
		  
		  {
			  rList = rList.minus([x-1,x-2])
		  }
		  
		  else if (item.GR_BED_NO == "A"){
			  
			  
			  rList = rList.minus([x+2])
		  }
		  
		  else{
			  rList = rList.minus([x+1])
		  }
	  }
	  
	  
	  rList = rList.minus(rListHoRsv)
	  
	  
	  def rt=RoomTransaction.createCriteria()
	  def rtList=rt.list{
		  or{
			  
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN'"+ fromdt +"' AND '"+todt+"'")
			  }
		  projections{
			  property('GRT_GR_ID')
			  }
		
	  }
	  
	  def rtHO=RoomTransaction.createCriteria()
	  def rtListHO=rtHO.list{
		  and{
			  
			  eq("GRT_GH_TYPE","HO")
		  
		  or{
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
		  }
	  }
	  
	 for (item in rtListHO){
		  def x = item.GRT_GR_ID as int
		  
		  if(item.GRT_BED_NO == "both")
		  
		  {
			  rList = rList.minus([x-1,x-2])
		  }
		  
		  else if (item.GRT_BED_NO == "A"){
			  
			  
			  rList = rList.minus([x+2])
		  }
		  
		  else{
			  rList = rList.minus([x+1])
		  }
	  }
	  
	 
	  def roomAvailList1 = rList.minus(rtList);
		
	  def room = Room.createCriteria()
	  def roomListHO = room.list{
		  
		  'in'("id",roomAvailList1)
		  
	   }
	  
	  
	  def r2=Room.createCriteria()
	  def rList2=r2.list{
		  eq("GR_TYPE","SJ")
		  projections{
			  property('id')
			  
			  
		  }
	  }
	  
	  
	  def r3=Room.createCriteria()
	  def rListSjRsv=r3.list{
		  
		  and{
			  
			  or{
				  sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GR_RESR_TO,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","SJ")
		  }
		  projections{
			  property('id')
			  
		  }
	  }
	  
	  def r5=Room.createCriteria()
	  def rListSjRsvAll=r5.list{
		  
		  and{
			  
			  or{
				   sqlRestriction("TO_CHAR(GR_RESR_FROM,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
				   sqlRestriction("TO_CHAR(GR_RESR_TO,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
			  
			  eq("GR_TYPE","SJ")
		  }
		  
	  }
	  
	  
	  for (item in rListSjRsvAll){
		  def x = item.id as int
		  
		  if(item.GR_BED_NO == "both")
		  
		  {
			  rList2 = rList2.minus([x-1,x-2])
		  }
		  
		  else if (item.GR_BED_NO == "A"){
			  
			  
			  rList2 = rList2.minus([x+2])
		  }
		  
		  else{
			  rList2 = rList2.minus([x+1])
		  }
	  }
	  rList2 = rList2.minus(rListSjRsv)
	  
	  
	  
	  def rtSJ=RoomTransaction.createCriteria()
	  def rtListSJ=rtSJ.list{
		  
		  and{
			  
			  eq("GRT_GH_TYPE","SJ")
		  or{
			  sqlRestriction("TO_CHAR(GRT_FROM_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  sqlRestriction("TO_CHAR(GRT_TO_DT,'YYYY-MM-DD') BETWEEN '"+ fromdt +"' AND '"+todt+"'")
			  }
		  }
	  }
	  
	  for (item in rtListSJ){
		  def x = item.GRT_GR_ID as int
		  
		  if(item.GRT_BED_NO == "both")
		  
		  {
			  rList2 = rList2.minus([x-1,x-2])
		  }
		  
		  else if (item.GRT_BED_NO == "A"){
			  
			  
			  rList2 = rList2.minus([x+2])
		  }
		  
		  else{
			  rList2 = rList2.minus([x+1])
		  }
	  }
	  
	  def roomAvailList2 = rList2.minus(rtList);
	  
	  
	def room2 = Room.createCriteria()
	def roomListSJ = room2.list{
		
		'in'("id",roomAvailList2)
		
	 }
	  
   /*  fromdt=Date.parse('dd-MM-YYYY',fromdt)
	 todt=Date.parse('dd-MM-YYYY',todt)*/
	 
	 render(view:"searchRoomAvailgh.gsp",model:[roomListHO:roomListHO,roomListSJ:roomListSJ,fromdt:fromdt,todt:todt])

  
  }
  
  
  
}
